---
title:  "I've been told I have really soft lips"
metadate: "hide"
categories: [ Rear Pussy ]
image: "https://external-preview.redd.it/UlxNnr6A00jBSo8W42HpR1-ycf33xpchhBYw0PpHIIQ.jpg?auto=webp&s=1f930a004711f5e3973dae1bc7f1e9d6b7fc0425"
thumb: "https://external-preview.redd.it/UlxNnr6A00jBSo8W42HpR1-ycf33xpchhBYw0PpHIIQ.jpg?width=1080&crop=smart&auto=webp&s=db7c2a35cdaad7a4d4f09c9c506c61f4c8409cb2"
visit: ""
---
I've been told I have really soft lips
