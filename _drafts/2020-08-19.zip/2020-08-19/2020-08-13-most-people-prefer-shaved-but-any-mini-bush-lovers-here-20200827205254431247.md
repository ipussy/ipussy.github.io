---
title:  "most people prefer shaved, but any mini bush lovers here?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/3jiw1a06xog51.jpg?auto=webp&s=b0dd273357be2ce7955f4d75babbe3b2d41e5d18"
thumb: "https://preview.redd.it/3jiw1a06xog51.jpg?width=1080&crop=smart&auto=webp&s=0cf80eb83bda944d79cfbc122120cdc94122685b"
visit: ""
---
most people prefer shaved, but any mini bush lovers here?
