---
title:  "Found some good lighting on the highway"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/ok49cog8pzh51.jpg?auto=webp&s=22856caeb73d6d1c78ba95be9b605509d4982cf5"
thumb: "https://preview.redd.it/ok49cog8pzh51.jpg?width=1080&crop=smart&auto=webp&s=66b19c22831f99a9984adfe3a8363196fa733164"
visit: ""
---
Found some good lighting on the highway
