---
title:  "100lbs, huge lips. All the better to grip with, my dear. [33]"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/g51i20gq08j51.jpg?auto=webp&s=b8f13da27b8178de001505e820dfbc1244ba9f15"
thumb: "https://preview.redd.it/g51i20gq08j51.jpg?width=1080&crop=smart&auto=webp&s=e13751b371f71327980133a01e71bbabf49f5808"
visit: ""
---
5'5", 100lbs, huge lips. All the better to grip with, my dear. [33]
