---
title:  "My tongue can’t reach, can you do it for me instead?"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/5pgwlintm7j51.jpg?auto=webp&s=ed26ec7ae118a2a94d3285133a502607bb4a27d8"
thumb: "https://preview.redd.it/5pgwlintm7j51.jpg?width=1080&crop=smart&auto=webp&s=b1f4783b1088b457449694c2ad1f726a978de9b9"
visit: ""
---
My tongue can’t reach, can you do it for me instead?
