---
title:  "I bought it for my boss but I let you guys look at it first...what you think ? 29f"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/ztpt8e23kuk51.jpg?auto=webp&s=eeb1311ff5b98b9a6cb43c7a04fcb9df1697475f"
thumb: "https://preview.redd.it/ztpt8e23kuk51.jpg?width=1080&crop=smart&auto=webp&s=a6401b30a8a84ea2b9280d754e4ddb103b22e6a6"
visit: ""
---
I bought it for my boss but I let you guys look at it first...what you think ? 29f
