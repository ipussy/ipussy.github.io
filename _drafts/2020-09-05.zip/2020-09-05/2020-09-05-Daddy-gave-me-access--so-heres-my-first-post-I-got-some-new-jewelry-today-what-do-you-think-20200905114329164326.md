---
title:  "Daddy gave me access 😄 so here's my first post, I got some new jewelry today what do you think!"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/qjcvbuppb9l51.jpg?auto=webp&s=c12bd05b2630cc699ba6f595c7abde0cf9fff958"
thumb: "https://preview.redd.it/qjcvbuppb9l51.jpg?width=1080&crop=smart&auto=webp&s=a5871eee087051f4bcbed92c5f0d1a9ac20246c4"
visit: ""
---
Daddy gave me access 😄 so here's my first post, I got some new jewelry today what do you think!
