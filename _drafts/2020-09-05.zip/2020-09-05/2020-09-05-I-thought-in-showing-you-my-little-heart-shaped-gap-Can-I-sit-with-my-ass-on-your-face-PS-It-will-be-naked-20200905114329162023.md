---
title:  "I thought in showing you my little heart shaped gap. Can I sit with my ass on your face? P.S: It will be naked."
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/3Vatbf6vBMCA9UMZ32hgoGBNVLmkiapxoiJ8kUhK0Xo.jpg?auto=webp&s=034b9f8ac1d2148dd7e43e0e23dce60b3de78886"
thumb: "https://external-preview.redd.it/3Vatbf6vBMCA9UMZ32hgoGBNVLmkiapxoiJ8kUhK0Xo.jpg?width=960&crop=smart&auto=webp&s=cbe5c704b25164cf3b89f79f11271e56a32b966b"
visit: ""
---
I thought in showing you my little heart shaped gap. Can I sit with my ass on your face? P.S: It will be naked.
