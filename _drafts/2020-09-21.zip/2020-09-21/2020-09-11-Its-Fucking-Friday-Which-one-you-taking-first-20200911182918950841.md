---
title:  "It’s (F)ucking Friday!!! Which one you taking first?? 😉☺️"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/2qerinjrrhm51.jpg?auto=webp&s=68256a03b5a670cf6095c59838962dfd960a6c71"
thumb: "https://preview.redd.it/2qerinjrrhm51.jpg?width=1080&crop=smart&auto=webp&s=3aebf2c8765101e53612efbe66e53d64f69413f3"
visit: ""
---
It’s (F)ucking Friday!!! Which one you taking first?? 😉☺️
