---
title:  "This is my favourite picture that I’ve ever taken! (f23)"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/197q6t7s54n51.jpg?auto=webp&s=6e2dd2dbc60b3c9641a87608f0fc9c025bf3db94"
thumb: "https://preview.redd.it/197q6t7s54n51.jpg?width=1080&crop=smart&auto=webp&s=c565c35ae0c56eb8b364ee08d9e2217e50ab01db"
visit: ""
---
This is my favourite picture that I’ve ever taken! (f23)
