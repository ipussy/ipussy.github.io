---
title:  "New here! What do you think of my kitty?"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/ag103d1dkgn51.jpg?auto=webp&s=6260ea5fc04944fe00a4d2536ff946e94efc207b"
thumb: "https://preview.redd.it/ag103d1dkgn51.jpg?width=1080&crop=smart&auto=webp&s=a5c028e156fc3d56e6aa5cedcadd22253761bea4"
visit: ""
---
New here! What do you think of my kitty?
