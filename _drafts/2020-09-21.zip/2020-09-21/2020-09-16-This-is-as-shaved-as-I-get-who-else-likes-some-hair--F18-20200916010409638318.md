---
title:  "This is as shaved as I get, who else likes some hair? 😚❤️ (F18)"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/ign75tr0ncn51.jpg?auto=webp&s=2eabeba6590cdda77c93b71dce7e4067f7ad34d4"
thumb: "https://preview.redd.it/ign75tr0ncn51.jpg?width=1080&crop=smart&auto=webp&s=1807db7011a65ef4523312ba5b7a24f273b16add"
visit: ""
---
This is as shaved as I get, who else likes some hair? 😚❤️ (F18)
