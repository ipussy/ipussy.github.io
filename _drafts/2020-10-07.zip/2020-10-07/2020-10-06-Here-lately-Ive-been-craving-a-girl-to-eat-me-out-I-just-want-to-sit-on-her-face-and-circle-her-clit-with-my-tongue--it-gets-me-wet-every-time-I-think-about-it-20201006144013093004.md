---
title:  "Here lately, I’ve been craving a girl to eat me out. I just want to sit on her face and circle her clit with my tongue 🤤 it gets me wet every time I think about it."
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/7rxwpi9x9fr51.jpg?auto=webp&s=2f2102cf76dc364313a091943b77d63db3371ff7"
thumb: "https://preview.redd.it/7rxwpi9x9fr51.jpg?width=640&crop=smart&auto=webp&s=77efc4e32bad2471949c3141e6b92461d94586ac"
visit: ""
---
Here lately, I’ve been craving a girl to eat me out. I just want to sit on her face and circle her clit with my tongue 🤤 it gets me wet every time I think about it.
