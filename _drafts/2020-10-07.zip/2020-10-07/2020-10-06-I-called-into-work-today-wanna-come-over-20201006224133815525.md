---
title:  "I called into work today, wanna come over?"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/yi8zifjwkhr51.jpg?auto=webp&s=15ac83df7a06d0059e6c6d4e5ea5fd1cf32543d6"
thumb: "https://preview.redd.it/yi8zifjwkhr51.jpg?width=1080&crop=smart&auto=webp&s=3f9fad829a70417a900468b3a81bb8ecf8817c3b"
visit: ""
---
I called into work today, wanna come over?
