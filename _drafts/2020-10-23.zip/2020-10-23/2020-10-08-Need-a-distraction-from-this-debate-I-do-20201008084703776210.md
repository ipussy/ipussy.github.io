---
title:  "Need a distraction from this debate? I do!"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/5q8tiv6ywrr51.jpg?auto=webp&s=94ab851ac94115dd6ebf218a96baba7ec5a775ca"
thumb: "https://preview.redd.it/5q8tiv6ywrr51.jpg?width=1080&crop=smart&auto=webp&s=7be98053bc06c3441a0472d84e5ff5567257de3f"
visit: ""
---
Need a distraction from this debate? I do!
