---
title:  "I just show the way. You have to do the rest. (F)"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/r6ydhh6rl8s51.jpg?auto=webp&s=3d466029792c9d0da58aa2d53034b786e560cb15"
thumb: "https://preview.redd.it/r6ydhh6rl8s51.jpg?width=1080&crop=smart&auto=webp&s=5ca0a370223b974aa2dbc221d01db481e2aff0ae"
visit: ""
---
I just show the way. You have to do the rest. (F)
