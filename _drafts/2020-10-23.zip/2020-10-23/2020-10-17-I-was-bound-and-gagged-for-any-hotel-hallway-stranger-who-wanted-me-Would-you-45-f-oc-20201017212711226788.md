---
title:  "I was bound and gagged for any hotel hallway stranger who wanted me. Would you? (45) (f) (oc) 👧🏼🙈🍆💦"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/27np96z9xnt51.jpg?auto=webp&s=5f3417732879812b36feb65024e41f564da02dde"
thumb: "https://preview.redd.it/27np96z9xnt51.jpg?width=1080&crop=smart&auto=webp&s=9e79c704765339dfb4ae674febc2709d1906bf6e"
visit: ""
---
I was bound and gagged for any hotel hallway stranger who wanted me. Would you? (45) (f) (oc) 👧🏼🙈🍆💦
