---
title:  "Thick thighs may save lives.. but swollen lips definitely grip dicks."
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/ge8754hjm2v51.jpg?auto=webp&s=d3450beade051db69832250e161e1afcfb28483e"
thumb: "https://preview.redd.it/ge8754hjm2v51.jpg?width=1080&crop=smart&auto=webp&s=d1a0cb3108cc70e25200726fc1629c6a8fad4ee8"
visit: ""
---
Thick thighs may save lives.. but swollen lips definitely grip dicks.
