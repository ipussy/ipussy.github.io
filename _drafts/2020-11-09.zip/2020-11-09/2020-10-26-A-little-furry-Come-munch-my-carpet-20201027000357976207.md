---
title:  "A little furry. Come munch my carpet."
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/r5sizbi3tgv51.jpg?auto=webp&s=641956bf4c709e89c0969ba8f9a6b32315978fbd"
thumb: "https://preview.redd.it/r5sizbi3tgv51.jpg?width=1080&crop=smart&auto=webp&s=5c3bfeaf2959e82504ae1799940974b6d111ac0c"
visit: ""
---
A little furry. Come munch my carpet.
