---
title:  "I got a new camera! Sharing what I first took on it"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/4lnmy52s5gv51.jpg?auto=webp&s=8a9ec0c923f105ee06017769634975d8ff2d0b5e"
thumb: "https://preview.redd.it/4lnmy52s5gv51.jpg?width=1080&crop=smart&auto=webp&s=313ab245197046f4e2a6390b8d030999bf5e3dce"
visit: ""
---
I got a new camera! Sharing what I first took on it
