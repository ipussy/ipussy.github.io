---
title:  "5'0 and 80lbs. My butt-plug makes my super-tight pussy even tighter! ;)"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/X4fnRgqP9eJogvrNmunk7n-vwqbFkPKpejf53OqpdNM.jpg?auto=webp&s=8fdd16efae1db0d927091f9fea2c5bd9c04ebc10"
thumb: "https://external-preview.redd.it/X4fnRgqP9eJogvrNmunk7n-vwqbFkPKpejf53OqpdNM.jpg?width=1080&crop=smart&auto=webp&s=da7d2d56eae2000912ec1d9a9ae08cbc467cb0b1"
visit: ""
---
5'0 and 80lbs. My butt-plug makes my super-tight pussy even tighter! ;)
