---
title:  "Took a close up of my kitty today for you all 😘"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/xeb2oppw0pz51.jpg?auto=webp&s=b3a1e3e86297af8aed21f3a2f209a701e5d2af00"
thumb: "https://preview.redd.it/xeb2oppw0pz51.jpg?width=1080&crop=smart&auto=webp&s=6e53ac27a01099a275470286c219c97f2be02d4b"
visit: ""
---
Took a close up of my kitty today for you all 😘
