---
title:  "If you have morning wood, you are welcome to stare at my pussy and asshole while you stroke."
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/isqu53nprd161.jpg?auto=webp&s=21e3beb50440c381560abc3706954f1abdafd0ec"
thumb: "https://preview.redd.it/isqu53nprd161.jpg?width=640&crop=smart&auto=webp&s=ff6dede1f45caad8733c3d2a16c8d4b7c41d437d"
visit: ""
---
If you have morning wood, you are welcome to stare at my pussy and asshole while you stroke.
