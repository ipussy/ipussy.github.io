---
title:  "I would be a good person to take on a road trip, can't you tell?"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/G0wwezkA0X16Zf0qZpFWS-lSScNy730bPy7B2qzF-pI.jpg?auto=webp&s=d64f9c168928d180e785f466490bb1bfb93ec556"
thumb: "https://external-preview.redd.it/G0wwezkA0X16Zf0qZpFWS-lSScNy730bPy7B2qzF-pI.jpg?width=1080&crop=smart&auto=webp&s=5e7f051f78220de4da23f5e58cd344111de501a5"
visit: ""
---
I would be a good person to take on a road trip, can't you tell?
