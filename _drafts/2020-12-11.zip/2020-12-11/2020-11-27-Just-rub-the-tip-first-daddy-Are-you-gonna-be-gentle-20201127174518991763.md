---
title:  "Just rub the tip first, daddy. Are you gonna be gentle??"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/s7sptb3w6r161.jpg?auto=webp&s=d7099efe04a8d48f73e552d87a03618a69fde838"
thumb: "https://preview.redd.it/s7sptb3w6r161.jpg?width=640&crop=smart&auto=webp&s=f47937dd13bf66240ae0e7f2efb3426210f0b57c"
visit: ""
---
Just rub the tip first, daddy. Are you gonna be gentle??
