---
title:  "5'0, 80lbs, plugged and ready to play. The tiniest pussy you've ever seen. ;)"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/zlAZd4j16ZrqAsOdxls7NPvzV7P6dU511fZUl7MWSqo.jpg?auto=webp&s=d5615dfac94b6a91087e6a994f014e19d42a6c04"
thumb: "https://external-preview.redd.it/zlAZd4j16ZrqAsOdxls7NPvzV7P6dU511fZUl7MWSqo.jpg?width=1080&crop=smart&auto=webp&s=e4b43a6d5dbc08405c1ad3e71fa64ff54eff3939"
visit: ""
---
5'0, 80lbs, plugged and ready to play. The tiniest pussy you've ever seen. ;)
