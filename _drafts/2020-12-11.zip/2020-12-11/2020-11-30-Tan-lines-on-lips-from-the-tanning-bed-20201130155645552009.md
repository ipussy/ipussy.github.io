---
title:  "Tan lines on lips from the tanning bed"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/6iq4dju7ac261.jpg?auto=webp&s=d17b647231bfc73914783ea81d616012eeeaff32"
thumb: "https://preview.redd.it/6iq4dju7ac261.jpg?width=1080&crop=smart&auto=webp&s=b1bb3f19f07c781ffa6e80c8cc1fef83d49a653b"
visit: ""
---
Tan lines on lips from the tanning bed
