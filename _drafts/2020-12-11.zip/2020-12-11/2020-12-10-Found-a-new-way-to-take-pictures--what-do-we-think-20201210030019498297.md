---
title:  "Found a new way to take pictures ;) what do we think?"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/vftbu73sh7461.jpg?auto=webp&s=9f8eb779705592e4b0f8de44eae924b114c8bfd3"
thumb: "https://preview.redd.it/vftbu73sh7461.jpg?width=640&crop=smart&auto=webp&s=16714d2cd487bac946ff8b8c8e98e913a5ec8e82"
visit: ""
---
Found a new way to take pictures ;) what do we think?
