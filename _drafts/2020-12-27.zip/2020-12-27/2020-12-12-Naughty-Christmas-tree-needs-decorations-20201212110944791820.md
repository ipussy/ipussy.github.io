---
title:  "Naughty Christmas tree needs decorations."
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/i0bipbaweo461.jpg?auto=webp&s=31f1060bdb4b0d5356db1cd76d8638990bc4aa0a"
thumb: "https://preview.redd.it/i0bipbaweo461.jpg?width=640&crop=smart&auto=webp&s=7a44ee1133c03811e3567ac8aa569f6e9d84650d"
visit: ""
---
Naughty Christmas tree needs decorations.
