---
title:  "Something sweet for the start of your week. 🍭 Your fave slutty budtender 😇 $3 for 30 days gets you instant access to over 100 pics and videos (and thats just my first 3 weeks) 💦 1 on 1 DMs, DAILY uploads, minimum of 3 full length vids a week 😈 NO PPV😜"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/1gzrkjdzk9561.png?auto=webp&s=cb0559002d0cd3b2cb29cee9c32b1da24a8c2b24"
thumb: "https://preview.redd.it/1gzrkjdzk9561.png?width=320&crop=smart&auto=webp&s=b35c187070f883aff0d35ef0c248864ab66f1153"
visit: ""
---
Something sweet for the start of your week. 🍭 Your fave slutty budtender 😇 $3 for 30 days gets you instant access to over 100 pics and videos (and thats just my first 3 weeks) 💦 1 on 1 DMs, DAILY uploads, minimum of 3 full length vids a week 😈 NO PPV😜
