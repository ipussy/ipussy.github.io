---
title:  "My favourite position to be during college lectures"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/nsdqqpz4px661.jpg?auto=webp&s=6a16a16dcf907df43ad3a7a58794c05203b3f1f4"
thumb: "https://preview.redd.it/nsdqqpz4px661.jpg?width=640&crop=smart&auto=webp&s=a9808bd86f39a2abf7254a6c7322d0f3f60bb630"
visit: ""
---
My favourite position to be during college lectures
