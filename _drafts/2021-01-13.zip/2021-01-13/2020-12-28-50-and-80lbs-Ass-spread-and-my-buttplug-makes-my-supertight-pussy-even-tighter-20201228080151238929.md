---
title:  "5'0 and 80lbs. Ass spread, and my butt-plug makes my super-tight pussy even tighter! ;)"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/qHkR6RtJ439MNRi-wCyvT5z5ySTXdNUGAiPfCfR1bds.jpg?auto=webp&s=d72922ad304bcc81f08bb6edc978d316e5f3b4a1"
thumb: "https://external-preview.redd.it/qHkR6RtJ439MNRi-wCyvT5z5ySTXdNUGAiPfCfR1bds.jpg?width=1080&crop=smart&auto=webp&s=cc25e57bbc96fd33d44a416dd867ab39e22dd151"
visit: ""
---
5'0 and 80lbs. Ass spread, and my butt-plug makes my super-tight pussy even tighter! ;)
