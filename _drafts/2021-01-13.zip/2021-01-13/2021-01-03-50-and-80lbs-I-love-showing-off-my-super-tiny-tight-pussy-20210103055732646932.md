---
title:  "5'0 and 80lbs. I love showing off my super tiny tight pussy ;)"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/jMdIzRnNax3FTp-vPUBW_7rgDFNiAY1abKAEtibc28o.jpg?auto=webp&s=5088b51bf6cf6e943735d1b7732c2faec655090d"
thumb: "https://external-preview.redd.it/jMdIzRnNax3FTp-vPUBW_7rgDFNiAY1abKAEtibc28o.jpg?width=1080&crop=smart&auto=webp&s=f138a45545c3736766c6d13ad2a0052706883c22"
visit: ""
---
5'0 and 80lbs. I love showing off my super tiny tight pussy ;)
