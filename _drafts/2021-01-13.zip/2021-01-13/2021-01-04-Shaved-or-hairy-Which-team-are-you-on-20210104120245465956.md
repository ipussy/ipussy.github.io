---
title:  "Shaved or hairy? Which team are you on?"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/3gnjja5xr8961.jpg?auto=webp&s=baac808f349022a5e70743adf007f8a2be64bd30"
thumb: "https://preview.redd.it/3gnjja5xr8961.jpg?width=1080&crop=smart&auto=webp&s=e108b8aa68a6355883c4cc86a586003b431e6bbf"
visit: ""
---
Shaved or hairy? Which team are you on?
