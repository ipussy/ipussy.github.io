---
title:  "First day of work 2021 but still found time to take this gem for y’all 💎 (OC)"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/39hr4fx5nl961.jpg?auto=webp&s=1cef28233cbfc817532a1d41fd5a6b65e1e5345a"
thumb: "https://preview.redd.it/39hr4fx5nl961.jpg?width=640&crop=smart&auto=webp&s=681c264a358729fee720db2dc172d2fda120ccae"
visit: ""
---
First day of work 2021 but still found time to take this gem for y’all 💎 (OC)
