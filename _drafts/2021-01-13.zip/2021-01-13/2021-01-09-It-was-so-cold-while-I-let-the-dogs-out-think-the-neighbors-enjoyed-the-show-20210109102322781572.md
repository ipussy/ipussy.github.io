---
title:  "It was so cold while I let the dogs out... think the neighbors enjoyed the show?"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/ba5qkwx688a61.jpg?auto=webp&s=5d226dbc47f71b6f386e88085732a16e26b5d85f"
thumb: "https://preview.redd.it/ba5qkwx688a61.jpg?width=1080&crop=smart&auto=webp&s=7957cca1d5c9d8fc9cc466fc5596fbad4e8077fa"
visit: ""
---
It was so cold while I let the dogs out... think the neighbors enjoyed the show?
