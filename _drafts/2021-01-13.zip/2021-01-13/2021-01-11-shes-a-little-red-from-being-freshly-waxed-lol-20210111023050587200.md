---
title:  "she’s a little red from being freshly waxed lol"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/vizsg7xyxja61.jpg?auto=webp&s=5bb7750e0f775f0c9becb653ccf8d29e87564cc7"
thumb: "https://preview.redd.it/vizsg7xyxja61.jpg?width=1080&crop=smart&auto=webp&s=3fed845f1a98d60ed81dbb0e4ba8e86f37d8a0c3"
visit: ""
---
she’s a little red from being freshly waxed lol
