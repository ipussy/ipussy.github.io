---
title:  "Come take it, daddy. This pussy is yours 💙"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/0jckycuopub61.jpg?auto=webp&s=15ec5b8c286f7797740c8e7d7d5c6a6f35cccab4"
thumb: "https://preview.redd.it/0jckycuopub61.jpg?width=640&crop=smart&auto=webp&s=cc4ac0eb596008f8717be317bd6e6b94a4c1efc9"
visit: ""
---
Come take it, daddy. This pussy is yours 💙
