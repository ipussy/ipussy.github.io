---
title:  "Freshly shaved and smooth. Do you wanna feel?"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/q6xkthkjssb61.jpg?auto=webp&s=ad39218c593ea27c6fd2f70bd24a6ac7e6690a4f"
thumb: "https://preview.redd.it/q6xkthkjssb61.jpg?width=960&crop=smart&auto=webp&s=e67517a3f572a5abf0891b16267e7a62fbe1a153"
visit: ""
---
Freshly shaved and smooth. Do you wanna feel?
