---
title:  "I don't want to go to work. Can I have a seat instead?"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/wveeyrd06xb61.jpg?auto=webp&s=8c077e36c8ea0c303651e83160d3aed3196398dc"
thumb: "https://preview.redd.it/wveeyrd06xb61.jpg?width=640&crop=smart&auto=webp&s=0d7355668c7126bbff7fcbf6240e51b522617921"
visit: ""
---
I don't want to go to work. Can I have a seat instead?
