---
title:  "I love having a petite frame and fat lips."
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/iu43vlxpitb61.gif?format=png8&s=5f932a202a69b4f4f1d89d357450ffd8061ae198"
thumb: "https://preview.redd.it/iu43vlxpitb61.gif?width=640&crop=smart&format=png8&s=b294ae1ec34366135375336ce54325fb6b68b54f"
visit: ""
---
I love having a petite frame and fat lips.
