---
title:  "Nurses need temperature checks, too 💋"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/uhqjphja0ae61.jpg?auto=webp&s=664e32889e7649cb6b307d6e12c22f20c9119a32"
thumb: "https://preview.redd.it/uhqjphja0ae61.jpg?width=640&crop=smart&auto=webp&s=8a6b89c09c691a213f1b016fe953622be1de18d6"
visit: ""
---
Nurses need temperature checks, too 💋
