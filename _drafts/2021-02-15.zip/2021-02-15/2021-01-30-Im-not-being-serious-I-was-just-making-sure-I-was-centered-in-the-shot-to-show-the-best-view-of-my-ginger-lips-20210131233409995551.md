---
title:  "I'm not being serious; I was just making sure I was centered in the shot to show the best view of my ginger lips"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/uv29qramnce61.gif?format=png8&s=bb0e4a0ddf766381b3520e9ad4db4bdafe0cf809"
thumb: "https://preview.redd.it/uv29qramnce61.gif?width=320&crop=smart&format=png8&s=6dff4c1c7ad69f3de19e6d7cf3f7974e8f029801"
visit: ""
---
I'm not being serious; I was just making sure I was centered in the shot to show the best view of my ginger lips
