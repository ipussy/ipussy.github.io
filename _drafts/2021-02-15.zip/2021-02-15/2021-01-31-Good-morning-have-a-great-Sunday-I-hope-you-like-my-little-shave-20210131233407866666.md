---
title:  "Good morning, have a great Sunday! I hope you like my little shave 😜"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/k0et1q9vvme61.jpg?auto=webp&s=d733618e5b6c8a7b467853e2a13aeffaf08bcc89"
thumb: "https://preview.redd.it/k0et1q9vvme61.jpg?width=1080&crop=smart&auto=webp&s=a88497d38571f3be3218e30114315d76ccbf597e"
visit: ""
---
Good morning, have a great Sunday! I hope you like my little shave 😜
