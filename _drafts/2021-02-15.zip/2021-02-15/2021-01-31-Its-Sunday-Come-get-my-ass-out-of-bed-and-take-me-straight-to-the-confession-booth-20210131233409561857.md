---
title:  "It's Sunday! Come get my ass out of bed and take me straight to the confession booth."
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/xexusy8i6ne61.jpg?auto=webp&s=d3cd496b78c46b65a46cc171d7873e9d70539377"
thumb: "https://preview.redd.it/xexusy8i6ne61.jpg?width=1080&crop=smart&auto=webp&s=74faa5314293a7de38dac46edfd497286fa7c893"
visit: ""
---
It's Sunday! Come get my ass out of bed and take me straight to the confession booth.
