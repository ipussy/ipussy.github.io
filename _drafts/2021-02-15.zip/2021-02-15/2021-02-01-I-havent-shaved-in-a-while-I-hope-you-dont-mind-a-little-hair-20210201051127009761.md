---
title:  "I haven’t shaved in a while, I hope you don’t mind a little hair! ;)"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/uHK9DC6Y_VzJeYsoyZHH-5BCXIWyAf6-TWjR5__k_90.jpg?auto=webp&s=f3b8de347a94cc7238ac89f606af42e30ec30cb2"
thumb: "https://external-preview.redd.it/uHK9DC6Y_VzJeYsoyZHH-5BCXIWyAf6-TWjR5__k_90.jpg?width=1080&crop=smart&auto=webp&s=25078054f70562a48c1164a91535597ba9109b45"
visit: ""
---
I haven’t shaved in a while, I hope you don’t mind a little hair! ;)
