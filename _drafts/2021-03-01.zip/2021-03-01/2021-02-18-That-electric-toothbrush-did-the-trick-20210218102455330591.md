---
title:  "That electric toothbrush did the trick"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/cllu1e4295i61.jpg?auto=webp&s=cb2f3b5472f57b105b23efbf6e1ea0808afc782f"
thumb: "https://preview.redd.it/cllu1e4295i61.jpg?width=1080&crop=smart&auto=webp&s=73ebd6369d1206303983225b57dfe7a88ddee4b1"
visit: ""
---
That electric toothbrush did the trick
