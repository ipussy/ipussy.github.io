---
title:  "Who wants to help check the Nurses temp and replace my finger?"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/h0zoqgn0x4i61.jpg?auto=webp&s=7f56c86b98cb7c0a1626cc26d9655bce4ddec3b2"
thumb: "https://preview.redd.it/h0zoqgn0x4i61.jpg?width=640&crop=smart&auto=webp&s=2a046be810152cffead3a71853eecb7f33e2d673"
visit: ""
---
Who wants to help check the Nurses temp and replace my finger?
