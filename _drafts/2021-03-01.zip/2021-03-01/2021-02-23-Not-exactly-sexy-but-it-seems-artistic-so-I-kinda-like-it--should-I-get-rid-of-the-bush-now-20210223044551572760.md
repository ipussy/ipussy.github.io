---
title:  "Not exactly sexy, but it seems artistic so I kinda like it 😋 should I get rid of the bush now?"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/6kar9exn63j61.jpg?auto=webp&s=793c696d09b6ba06473335264c3293e8f406d1a6"
thumb: "https://preview.redd.it/6kar9exn63j61.jpg?width=1080&crop=smart&auto=webp&s=e2983042ba260558bb20a1d6f5edc8426682fb6a"
visit: ""
---
Not exactly sexy, but it seems artistic so I kinda like it 😋 should I get rid of the bush now?
