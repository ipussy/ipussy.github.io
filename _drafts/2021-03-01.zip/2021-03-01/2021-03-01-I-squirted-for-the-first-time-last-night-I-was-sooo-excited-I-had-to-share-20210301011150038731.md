---
title:  "I squirted for the first time last night. I was sooo excited I had to share"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/veyvk9ctf9k61.jpg?auto=webp&s=ca4808eb438898cfec25ed8af6da7cc7e383fdb8"
thumb: "https://preview.redd.it/veyvk9ctf9k61.jpg?width=1080&crop=smart&auto=webp&s=181096f8361265bb1d8d5f77231161ff586c02f1"
visit: ""
---
I squirted for the first time last night. I was sooo excited I had to share
