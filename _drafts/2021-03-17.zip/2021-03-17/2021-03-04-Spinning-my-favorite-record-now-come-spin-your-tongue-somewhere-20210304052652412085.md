---
title:  "Spinning my favorite record... now come spin your tongue somewhere 💧🍦💙"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/DZyan8T8gfgi_ptm3FyjDjRIoL5zu1vjPNLHMhCCrHQ.jpg?auto=webp&s=263d006b2685d2460a79cf5de3136500f2af5140"
thumb: "https://external-preview.redd.it/DZyan8T8gfgi_ptm3FyjDjRIoL5zu1vjPNLHMhCCrHQ.jpg?width=1080&crop=smart&auto=webp&s=aa1e71aace963cee384fe1774569fea615e3ca1c"
visit: ""
---
Spinning my favorite record... now come spin your tongue somewhere 💧🍦💙
