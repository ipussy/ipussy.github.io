---
title:  "Freshly shaved and waiting for you in my favorite position..."
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/QD8jpFavGiVrNxl2xg0--GvsRZvI5F4sBxCxozupdPQ.jpg?auto=webp&s=1125d07c9eed70dddb847cf0340d088a303e277e"
thumb: "https://external-preview.redd.it/QD8jpFavGiVrNxl2xg0--GvsRZvI5F4sBxCxozupdPQ.jpg?width=1080&crop=smart&auto=webp&s=195d0070008c5dec4a65386b2ba78ede4b188b95"
visit: ""
---
Freshly shaved and waiting for you in my favorite position...
