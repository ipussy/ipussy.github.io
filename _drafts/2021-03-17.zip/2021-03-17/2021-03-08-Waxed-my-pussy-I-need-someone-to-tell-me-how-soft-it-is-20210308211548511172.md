---
title:  "Waxed my pussy. I need someone to tell me how soft it is"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/c10g0avm6tl61.jpg?auto=webp&s=a8ae0a3ac447126def86ec9689a46e533a21b2d6"
thumb: "https://preview.redd.it/c10g0avm6tl61.jpg?width=1080&crop=smart&auto=webp&s=2937fa99f4a2f46b405493f07ee164727fd143b6"
visit: ""
---
Waxed my pussy. I need someone to tell me how soft it is
