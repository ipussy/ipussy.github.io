---
title:  "24yo pussy after a fresh shave. What do you think?"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/3E9zrNvSfi2AyrHZt723N-a0J6KJz-W5PG-vF6J_iEc.jpg?auto=webp&s=a596180f3e7072ef6ec7ddf9b11d1370663c7a46"
thumb: "https://external-preview.redd.it/3E9zrNvSfi2AyrHZt723N-a0J6KJz-W5PG-vF6J_iEc.jpg?width=640&crop=smart&auto=webp&s=769d928dd1af327c4da731893d4779a5f856d22c"
visit: ""
---
24yo pussy after a fresh shave. What do you think?
