---
title:  "You’ve got a tongue and I’ve got a pussy. What a coincidence... You wouldn’t be busy at the moment, would ya?"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/ynordm3yhin61.jpg?auto=webp&s=ca6696eb28e4ed69006ed98101d2fb9827da58fc"
thumb: "https://preview.redd.it/ynordm3yhin61.jpg?width=1080&crop=smart&auto=webp&s=77bb4494583fc78c469a03c3c548dfce8be05c3c"
visit: ""
---
You’ve got a tongue and I’ve got a pussy. What a coincidence... You wouldn’t be busy at the moment, would ya?
