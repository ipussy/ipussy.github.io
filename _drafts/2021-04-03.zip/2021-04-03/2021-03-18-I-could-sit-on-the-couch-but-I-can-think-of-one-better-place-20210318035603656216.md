---
title:  "I could sit on the couch but I can think of one better place..."
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/f7svvv798nn61.jpg?auto=webp&s=bd0f735ef5bdaef2318483aef32959887f66ea08"
thumb: "https://preview.redd.it/f7svvv798nn61.jpg?width=1080&crop=smart&auto=webp&s=67635f6a6b02d0cf1adabef887457f5324d9fe19"
visit: ""
---
I could sit on the couch but I can think of one better place...
