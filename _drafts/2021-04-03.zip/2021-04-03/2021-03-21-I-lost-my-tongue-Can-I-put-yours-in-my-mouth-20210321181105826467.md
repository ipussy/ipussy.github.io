---
title:  "I lost my tongue! Can I put yours in my mouth?"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/QEAsypIZ29O5qgxHeEr9F0zUv6IRJsq9tMXSRwL4t4Y.png?auto=webp&s=71aa79b965d6fa5ae9dde3ad6976b66716832a41"
thumb: "https://external-preview.redd.it/QEAsypIZ29O5qgxHeEr9F0zUv6IRJsq9tMXSRwL4t4Y.png?width=640&crop=smart&auto=webp&s=47c159dcfaf4e7027f0934ce449b00676dd1376d"
visit: ""
---
I lost my tongue! Can I put yours in my mouth?
