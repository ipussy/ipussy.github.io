---
title:  "Hopefully you can ignore my unnecessarily serious facial expression (I was making sure I was centered in the shot) and just focus on the subject matter:: my massive lips"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/BSQ_2EmCzbiOWCptHwajli3WjcAuYOgUkKJy8cy3O6c.jpg?auto=webp&s=6fdd2274c16a0d8d3224887efc27b84477991ff0"
thumb: "https://external-preview.redd.it/BSQ_2EmCzbiOWCptHwajli3WjcAuYOgUkKJy8cy3O6c.jpg?width=640&crop=smart&auto=webp&s=0f8a9b6c1af64fbd3c491e3fb1fbcc5ffaa732b4"
visit: ""
---
Hopefully you can ignore my unnecessarily serious facial expression (I was making sure I was centered in the shot) and just focus on the subject matter:: my massive lips
