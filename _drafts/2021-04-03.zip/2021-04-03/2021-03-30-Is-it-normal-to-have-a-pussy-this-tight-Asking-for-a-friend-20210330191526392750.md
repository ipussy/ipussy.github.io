---
title:  "Is it normal to have a pussy this tight? Asking for a friend"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/jla3x2hac5q61.jpg?auto=webp&s=3dd94a50e8bd11f9f0ec68229981d5f9dc3234e0"
thumb: "https://preview.redd.it/jla3x2hac5q61.jpg?width=1080&crop=smart&auto=webp&s=49f2521247f859691323f2235b60564c3f105ffe"
visit: ""
---
Is it normal to have a pussy this tight? Asking for a friend
