---
title:  "you guys. the description for this subreddit is so funny lmao anyways here's my tampon tunnel"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/ZgOyu8SU3WfU5htFbBY-7Ef8cbWvWREfr1C2PFxrIZs.jpg?auto=webp&s=18ae3c2388a7c43a2f75253b2f80b80614d233b7"
thumb: "https://external-preview.redd.it/ZgOyu8SU3WfU5htFbBY-7Ef8cbWvWREfr1C2PFxrIZs.jpg?width=1080&crop=smart&auto=webp&s=fa5c0fb4cd5570fe60c90c8ed9855ff2d8eaffda"
visit: ""
---
you guys. the description for this subreddit is so funny lmao anyways here's my tampon tunnel
