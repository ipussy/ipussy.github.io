---
title:  "5'0 and 80lbs English girl here, I'm as small as my tiny pussy is ;)"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/0-oS5g_-VlOkyTzc15_XYuI5kGS7rhK7lSMjEfmHgKc.jpg?auto=webp&s=586db4d231c8eba12d3e1550f95805207392d6c0"
thumb: "https://external-preview.redd.it/0-oS5g_-VlOkyTzc15_XYuI5kGS7rhK7lSMjEfmHgKc.jpg?width=1080&crop=smart&auto=webp&s=5b33ff19abb34912b93065ef944faaab3679154d"
visit: ""
---
5'0 and 80lbs English girl here, I'm as small as my tiny pussy is ;)
