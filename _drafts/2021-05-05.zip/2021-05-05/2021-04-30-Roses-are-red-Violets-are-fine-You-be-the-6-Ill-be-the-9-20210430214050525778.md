---
title:  "Roses are red. Violets are fine. You be the 6. I’ll be the 9."
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/9qd1osfj6bw61.jpg?auto=webp&s=6765dbca7a3d17961b6991f960786b34a504efae"
thumb: "https://preview.redd.it/9qd1osfj6bw61.jpg?width=1080&crop=smart&auto=webp&s=89d03f3537e604febda9d96c9202d54216412c09"
visit: ""
---
Roses are red. Violets are fine. You be the 6. I’ll be the 9.
