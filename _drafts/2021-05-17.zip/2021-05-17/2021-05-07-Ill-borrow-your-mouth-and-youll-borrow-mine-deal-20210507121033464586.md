---
title:  "I'll borrow your mouth and you'll borrow mine, deal?"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/upht5h3u8mx61.jpg?auto=webp&s=80ed8889acf7171e860752a48949b93a63f40f82"
thumb: "https://preview.redd.it/upht5h3u8mx61.jpg?width=1080&crop=smart&auto=webp&s=52b638811171c364ea8f53041ecc0de7d8134907"
visit: ""
---
I'll borrow your mouth and you'll borrow mine, deal?
