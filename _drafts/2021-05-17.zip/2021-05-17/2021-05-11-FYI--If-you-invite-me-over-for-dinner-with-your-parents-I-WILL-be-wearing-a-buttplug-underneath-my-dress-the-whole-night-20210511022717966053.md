---
title:  "FYI - If you invite me over for dinner with your parents, I WILL be wearing a buttplug underneath my dress the whole night."
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/nby322g8ccy61.jpg?auto=webp&s=d6726c95dc25208709c28282d8fce7515b4e3136"
thumb: "https://preview.redd.it/nby322g8ccy61.jpg?width=1080&crop=smart&auto=webp&s=66b31c55d4c63aa29227ed950b35405457b1db62"
visit: ""
---
FYI - If you invite me over for dinner with your parents, I WILL be wearing a buttplug underneath my dress the whole night.
