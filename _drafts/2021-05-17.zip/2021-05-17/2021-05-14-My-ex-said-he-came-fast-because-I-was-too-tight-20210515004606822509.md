---
title:  "My ex said he came fast because I was too tight"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/9n3uuah684z61.jpg?auto=webp&s=760732aa87da171f27e6e2b60c61b7809a71ef26"
thumb: "https://preview.redd.it/9n3uuah684z61.jpg?width=1080&crop=smart&auto=webp&s=01e75562b78378b8e16b722bb3c77de508a66cce"
visit: ""
---
My ex said he came fast because I was too tight
