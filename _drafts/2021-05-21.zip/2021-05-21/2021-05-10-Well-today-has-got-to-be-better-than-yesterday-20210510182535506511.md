---
title:  "Well today has got to be better than yesterday :)"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/c278e4u5q9y61.jpg?auto=webp&s=98787db480ec661e4b5652c308047d994dbbdde8"
thumb: "https://preview.redd.it/c278e4u5q9y61.jpg?width=1080&crop=smart&auto=webp&s=92be71cc7914a47e1820760396fd4bbd662231c9"
visit: ""
---
Well today has got to be better than yesterday :)
