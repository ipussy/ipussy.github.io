---
title:  "My husband says he likes my face better than my pussy.. so I’ll show you instead"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/5l7hi7a4xqz61.jpg?auto=webp&s=2c1331986ecfb331e7094e8ee863da26b42fca57"
thumb: "https://preview.redd.it/5l7hi7a4xqz61.jpg?width=1080&crop=smart&auto=webp&s=3c14939ea2ff60222c55f5041bf2a53f51a261d6"
visit: ""
---
My husband says he likes my face better than my pussy.. so I’ll show you instead
