---
title:  "Your Nurse is bent over in front of you like this .. what’s your next move?"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/lapz3pfkjtz61.jpg?auto=webp&s=b95b2bf88ce1843830311a087314528b7d2f2b08"
thumb: "https://preview.redd.it/lapz3pfkjtz61.jpg?width=640&crop=smart&auto=webp&s=39e93b8b8d77cf1aa82e7c1f0fcb718d9a2732d7"
visit: ""
---
Your Nurse is bent over in front of you like this .. what’s your next move?
