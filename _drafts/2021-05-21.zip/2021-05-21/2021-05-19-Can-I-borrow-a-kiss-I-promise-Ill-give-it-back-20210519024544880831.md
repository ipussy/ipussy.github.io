---
title:  "Can I borrow a kiss? I promise I’ll give it back."
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/qr27gi9hgxz61.jpg?auto=webp&s=682a0219a3483280c38550cfb29dac9cfd532065"
thumb: "https://preview.redd.it/qr27gi9hgxz61.jpg?width=640&crop=smart&auto=webp&s=92ac9b5570e85607d2d6803b38ee2f4bfcef187c"
visit: ""
---
Can I borrow a kiss? I promise I’ll give it back.
