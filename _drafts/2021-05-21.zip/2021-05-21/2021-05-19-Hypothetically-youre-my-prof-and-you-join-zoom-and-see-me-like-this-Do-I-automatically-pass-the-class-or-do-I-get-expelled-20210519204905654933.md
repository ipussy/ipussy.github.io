---
title:  "Hypothetically, you’re my prof and you join zoom and see me like this. Do I automatically pass the class or do I get expelled? 😅💕"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/epm7pthfu2071.jpg?auto=webp&s=c0e8a8fb4c6ca4f51d63f4bb753a6ff37cac7601"
thumb: "https://preview.redd.it/epm7pthfu2071.jpg?width=1080&crop=smart&auto=webp&s=04d7483faafdeb9639777df383db42e7b009b7d5"
visit: ""
---
Hypothetically, you’re my prof and you join zoom and see me like this. Do I automatically pass the class or do I get expelled? 😅💕
