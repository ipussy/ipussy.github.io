---
title:  "Freshly waxed, smooth as fuck. Drip. Drip."
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/m6azgomuv9071.jpg?auto=webp&s=066d066b6a9d950352f25b2368c9723e925228fb"
thumb: "https://preview.redd.it/m6azgomuv9071.jpg?width=1080&crop=smart&auto=webp&s=7e208f4a5d3c4325171e32a76e21d16c81ee453b"
visit: ""
---
Freshly waxed, smooth as fuck. Drip. Drip.
