---
title:  "I wish someone’s tongue was in me right about now"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/zemgg31v8n271.jpg?auto=webp&s=133f21d4c0397666086634bbc0d9c40b88f30947"
thumb: "https://preview.redd.it/zemgg31v8n271.jpg?width=1080&crop=smart&auto=webp&s=be5886ad6e988afac24ab61dcf228b91ba399be2"
visit: ""
---
I wish someone’s tongue was in me right about now
