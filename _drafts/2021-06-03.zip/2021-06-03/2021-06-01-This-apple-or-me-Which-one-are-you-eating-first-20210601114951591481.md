---
title:  "This apple or me? Which one are you eating first?"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/g5exxu4vjk271.jpg?auto=webp&s=65f0e9f3d8b3f8da0aa8fc8df0bf4ca4d94ad880"
thumb: "https://preview.redd.it/g5exxu4vjk271.jpg?width=1080&crop=smart&auto=webp&s=1f34ce849909506244f301009e7bc4d6c2b5bfaa"
visit: ""
---
This apple or me? Which one are you eating first?
