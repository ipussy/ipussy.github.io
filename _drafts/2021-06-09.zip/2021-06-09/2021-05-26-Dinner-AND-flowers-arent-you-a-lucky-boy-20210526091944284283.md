---
title:  "Dinner AND flowers, aren’t you a lucky boy!"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/p2zh9kq07d171.jpg?auto=webp&s=9fe981679002b4ef1c264bd8119d8d8a0ecf9366"
thumb: "https://preview.redd.it/p2zh9kq07d171.jpg?width=1080&crop=smart&auto=webp&s=1593e43de380c075a941feeb283960dd8a251b4b"
visit: ""
---
Dinner AND flowers, aren’t you a lucky boy!
