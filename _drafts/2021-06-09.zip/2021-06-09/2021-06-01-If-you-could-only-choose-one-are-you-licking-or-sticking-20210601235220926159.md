---
title:  "If you could only choose one, are you licking or sticking?"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/jory1kapmo271.jpg?auto=webp&s=f2b0872f335a1745a10d4e5773c80d9745366504"
thumb: "https://preview.redd.it/jory1kapmo271.jpg?width=640&crop=smart&auto=webp&s=a9f1bb2dd48d0e9a9d70e3915101bdbf2e1d7149"
visit: ""
---
If you could only choose one, are you licking or sticking?
