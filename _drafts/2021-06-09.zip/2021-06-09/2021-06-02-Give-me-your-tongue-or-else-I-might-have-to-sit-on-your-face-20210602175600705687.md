---
title:  "Give me your tongue, or else I might have to sit on your face."
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/bJsCGSFAV0zLOLFdnxUMMjl7d4mEnN3rNgwAURkvGwY.jpg?auto=webp&s=554e0d69d2d4a43c3fd975e7d68a6822b7a13adb"
thumb: "https://external-preview.redd.it/bJsCGSFAV0zLOLFdnxUMMjl7d4mEnN3rNgwAURkvGwY.jpg?width=1080&crop=smart&auto=webp&s=fdbc01f6bf425a53b3d42da869666143eb136846"
visit: ""
---
Give me your tongue, or else I might have to sit on your face.
