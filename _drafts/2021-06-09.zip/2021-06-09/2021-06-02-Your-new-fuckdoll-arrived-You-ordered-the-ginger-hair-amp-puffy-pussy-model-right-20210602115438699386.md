---
title:  "Your new fuckdoll arrived! You ordered the ginger hair &amp; puffy pussy model right?"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/la3php0q7s271.jpg?auto=webp&s=6e3d7c9bae12aec9ff00bd55e1e7a71b4de65f3a"
thumb: "https://preview.redd.it/la3php0q7s271.jpg?width=1080&crop=smart&auto=webp&s=785ef58ce96d039110c2b0252ff5f61f5c6edea6"
visit: ""
---
Your new fuckdoll arrived! You ordered the ginger hair &amp; puffy pussy model right?
