---
title:  "For my next installation, I call it ‘student nurse in doggy’"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/wPBhW3VNZxxpVcrV-3G38ISo_uYvkcI6-Jx2KjpBDEg.jpg?auto=webp&s=e2de04475532bc7b75e04c27071d887bcb1d8fc3"
thumb: "https://external-preview.redd.it/wPBhW3VNZxxpVcrV-3G38ISo_uYvkcI6-Jx2KjpBDEg.jpg?width=640&crop=smart&auto=webp&s=9849ff8a093d25694fb96b5f2d7fc46bf98f0216"
visit: ""
---
For my next installation, I call it ‘student nurse in doggy’
