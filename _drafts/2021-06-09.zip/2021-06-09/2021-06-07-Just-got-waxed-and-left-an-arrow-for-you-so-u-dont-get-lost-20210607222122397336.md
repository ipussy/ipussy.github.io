---
title:  "Just got waxed and left an arrow for you so u dont get lost"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/36v6iziomu371.jpg?auto=webp&s=3ff8de743cbd80c274134e53b48f948c33c0e80a"
thumb: "https://preview.redd.it/36v6iziomu371.jpg?width=1080&crop=smart&auto=webp&s=d9e949877bf14a6d21536da3460206b6c26af1e0"
visit: ""
---
Just got waxed and left an arrow for you so u dont get lost
