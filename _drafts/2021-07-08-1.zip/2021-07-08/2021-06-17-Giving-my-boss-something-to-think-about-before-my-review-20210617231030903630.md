---
title:  "Giving my boss something to think about before my review"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/71gafdj1ou571.jpg?auto=webp&s=30da62d6136e5e98199e2ce45ac58f3e540d8936"
thumb: "https://preview.redd.it/71gafdj1ou571.jpg?width=640&crop=smart&auto=webp&s=844b4cd8a426611373ea5143b7e10e2cf0fa78d0"
visit: ""
---
Giving my boss something to think about before my review
