---
title:  "Don’t stick out your tongue unless you intend to use it."
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/xvsds0gg0m771.jpg?auto=webp&s=f06fcd1947c4b6db4fd8a7efea6f7b7d9f5dba26"
thumb: "https://preview.redd.it/xvsds0gg0m771.jpg?width=1080&crop=smart&auto=webp&s=675c1e569d503781caaeea5d9a07b2cc80c0695b"
visit: ""
---
Don’t stick out your tongue unless you intend to use it.
