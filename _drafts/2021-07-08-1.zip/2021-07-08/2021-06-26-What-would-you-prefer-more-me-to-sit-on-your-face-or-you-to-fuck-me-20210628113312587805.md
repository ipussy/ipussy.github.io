---
title:  "What would you prefer more, me to sit on your face or you to fuck me?"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/TrbX1MdEwY8r-s-z4aPvih1m81C5QIqtttI_2kqmX8k.jpg?auto=webp&s=01da82811eb647241f8b0c7089b9fc8e9373f669"
thumb: "https://external-preview.redd.it/TrbX1MdEwY8r-s-z4aPvih1m81C5QIqtttI_2kqmX8k.jpg?width=1080&crop=smart&auto=webp&s=85c6bc56d47439fb6dcbd090d2e89bb0bdb0f581"
visit: ""
---
What would you prefer more, me to sit on your face or you to fuck me?
