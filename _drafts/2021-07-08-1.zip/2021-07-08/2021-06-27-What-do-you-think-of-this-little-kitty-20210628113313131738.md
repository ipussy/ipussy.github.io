---
title:  "What do you think of this little kitty?"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/dxup5ma51p771.jpg?auto=webp&s=1c89f027c2d63244c06571960dc97d91f8804aac"
thumb: "https://preview.redd.it/dxup5ma51p771.jpg?width=1080&crop=smart&auto=webp&s=c4c13c5ec6beeda3424d02bc4faca0f1d1b99b0f"
visit: ""
---
What do you think of this little kitty?
