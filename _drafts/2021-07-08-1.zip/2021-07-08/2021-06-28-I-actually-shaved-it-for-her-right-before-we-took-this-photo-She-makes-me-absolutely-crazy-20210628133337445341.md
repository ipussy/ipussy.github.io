---
title:  "I actually shaved it for her right before we took this photo. She makes me absolutely crazy."
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/s8ez9kqtwx771.jpg?auto=webp&s=dd699804470134a70a7f6f6e91a6ed1a0ae4c89f"
thumb: "https://preview.redd.it/s8ez9kqtwx771.jpg?width=640&crop=smart&auto=webp&s=2d21a28a0595c7f04d0e4a26c5253f465a20a542"
visit: ""
---
I actually shaved it for her right before we took this photo. She makes me absolutely crazy.
