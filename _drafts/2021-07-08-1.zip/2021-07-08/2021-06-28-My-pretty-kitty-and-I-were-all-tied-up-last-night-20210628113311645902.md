---
title:  "My pretty kitty and I were all tied up last night! 😈"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/81g0fp6w9x771.jpg?auto=webp&s=d3ba23562121080884c45dc5d213f8c4d492f720"
thumb: "https://preview.redd.it/81g0fp6w9x771.jpg?width=640&crop=smart&auto=webp&s=daa9951007cbc81df657a3b9c3bccf191872efb6"
visit: ""
---
My pretty kitty and I were all tied up last night! 😈
