---
title:  "While waiting for your next instruction"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/11kmlx77y6671.jpg?auto=webp&s=9ed7c1c5ea19c4d559ec5d931e33700ef2799b3d"
thumb: "https://preview.redd.it/11kmlx77y6671.jpg?width=1080&crop=smart&auto=webp&s=16af6925b282f11c605d86c154b99ccdeb0c5b10"
visit: ""
---
While waiting for your next instruction
