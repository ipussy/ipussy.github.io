---
title:  "I'm finally in my last year of psychology! How is it celebrated? 🧐"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/ybp9uszypfc71.jpg?auto=webp&s=5566d6f86a28593f0decb8cf5e05b3ed297899cd"
thumb: "https://preview.redd.it/ybp9uszypfc71.jpg?width=640&crop=smart&auto=webp&s=27b1025616f79c6b7f34dce191f4795b16ebb210"
visit: ""
---
I'm finally in my last year of psychology! How is it celebrated? 🧐
