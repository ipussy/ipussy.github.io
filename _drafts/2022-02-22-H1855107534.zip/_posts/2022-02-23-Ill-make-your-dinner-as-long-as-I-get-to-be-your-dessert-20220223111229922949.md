---
title:  "I’ll make your dinner as long as I get to be your dessert"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/1vycgJ-kL3c0z-KndYV8gNcc0tp31deTcUyi1Mqpyn4.jpg?auto=webp&s=36ea074442d92c9a3ed0faae485a6f732579e9ce"
thumb: "https://external-preview.redd.it/1vycgJ-kL3c0z-KndYV8gNcc0tp31deTcUyi1Mqpyn4.jpg?width=1080&crop=smart&auto=webp&s=957f1462901c0bdf3d6c3c6696385cecd2014c31"
visit: ""
---
I’ll make your dinner as long as I get to be your dessert
