---
title:  "Stockings and a freshly shaved rear clam"
metadate: "hide"
categories: [ Rear Pussy ]
image: "https://external-preview.redd.it/Ox7Hj5Jc4pa9SiI1T1uOwAbFd_KppIDCAzyOm0ZdkFI.jpg?auto=webp&s=ce2c155acedece0acd7c1c10476594683acafe62"
thumb: "https://external-preview.redd.it/Ox7Hj5Jc4pa9SiI1T1uOwAbFd_KppIDCAzyOm0ZdkFI.jpg?width=1080&crop=smart&auto=webp&s=d4c62510903084c5e34056d88d1ed2a28764b189"
visit: ""
---
Stockings and a freshly shaved rear clam
