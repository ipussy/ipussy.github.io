---
title:  "Can i borrow your tongue for a few minutes? 😇"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/93HVpU-bJ4mf9dcrWk-VhmHzZc4HLJgP0l9EpHfBYMQ.jpg?auto=webp&s=8c6e594282df32860c61ad4bd811636071b06b84"
thumb: "https://external-preview.redd.it/93HVpU-bJ4mf9dcrWk-VhmHzZc4HLJgP0l9EpHfBYMQ.jpg?width=1080&crop=smart&auto=webp&s=211d458cf058af86c0a980a7a6175cd7236e0365"
visit: ""
---
Can i borrow your tongue for a few minutes? 😇
