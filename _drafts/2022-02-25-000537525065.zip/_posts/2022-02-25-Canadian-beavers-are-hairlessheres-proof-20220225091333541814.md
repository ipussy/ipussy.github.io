---
title:  "Canadian beavers are hairless…here’s proof!"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/RTmYUhpyooiY1mbWwiABRmu4DgZNpXWZOc-Bq878M_U.jpg?auto=webp&s=c01e9cf3cec61f9263d57e5a0d28820b3de7e307"
thumb: "https://external-preview.redd.it/RTmYUhpyooiY1mbWwiABRmu4DgZNpXWZOc-Bq878M_U.jpg?width=216&crop=smart&auto=webp&s=357b5b2497f659e71fa45ef8deaf60e4be0b006b"
visit: ""
---
Canadian beavers are hairless…here’s proof!
