---
title:  "It’s been too long since it was licked…I may need to borrow your tongue"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/6cyzk77emvj81.jpg?auto=webp&s=3ad989c8b6de6481a2159a25490b0a908eefbea2"
thumb: "https://preview.redd.it/6cyzk77emvj81.jpg?width=1080&crop=smart&auto=webp&s=20285d48e1087ad5c1e8ddcfde26f59df34cb17c"
visit: ""
---
It’s been too long since it was licked…I may need to borrow your tongue
