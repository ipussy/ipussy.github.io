---
title:  "it’s a tight fit so i’ll hold her open while you push yourself inside 😉"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/0XZ48Hrlwf8uM9EjIr3qKq9KgSexTr56NFGgV3PWvOY.jpg?auto=webp&s=11cd4ac4423f085522506c47d8ac14b94bd5aa10"
thumb: "https://external-preview.redd.it/0XZ48Hrlwf8uM9EjIr3qKq9KgSexTr56NFGgV3PWvOY.jpg?width=1080&crop=smart&auto=webp&s=defba5645af7b75dfdf79829daf28e3c09aa5de5"
visit: ""
---
it’s a tight fit so i’ll hold her open while you push yourself inside 😉
