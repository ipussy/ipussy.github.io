---
title:  "Do flexible Canadians make you happy?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/MyOFd-2wb9hHfdwaYuviiXpl5Zt0YRJOVyXuCJa1vTo.jpg?auto=webp&s=3c7c1e1dc3e25659a382e8713c5fc072da855560"
thumb: "https://external-preview.redd.it/MyOFd-2wb9hHfdwaYuviiXpl5Zt0YRJOVyXuCJa1vTo.jpg?width=216&crop=smart&auto=webp&s=2e7a1b3b3a9ed111132d8e716f07998a30fe2c7f"
visit: ""
---
Do flexible Canadians make you happy?
