---
title:  "First trim in forever. How’s she look?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/Y_v1MAP_nlIKlsKFMKe0MEkWIcTM6qUVYUxodFMxqEo.jpg?auto=webp&s=95d260744167185156cbd8b00e366f4ed01d59f5"
thumb: "https://external-preview.redd.it/Y_v1MAP_nlIKlsKFMKe0MEkWIcTM6qUVYUxodFMxqEo.jpg?width=640&crop=smart&auto=webp&s=280a5db486d2af73859f022eed5fd035731a8f60"
visit: ""
---
First trim in forever. How’s she look?
