---
title:  "Just look at this shaved pink pussy!"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/vSgg1gpzx_828slvzWZW7noa0-jsWWKkrfSncEYQ5C8.jpg?auto=webp&s=07cdf4356b0a10da2071fb77338e2457b2e898b7"
thumb: "https://external-preview.redd.it/vSgg1gpzx_828slvzWZW7noa0-jsWWKkrfSncEYQ5C8.jpg?width=1080&crop=smart&auto=webp&s=91c7eae201380fb5cefadc560c9b59ce89382b8b"
visit: ""
---
Just look at this shaved pink pussy!
