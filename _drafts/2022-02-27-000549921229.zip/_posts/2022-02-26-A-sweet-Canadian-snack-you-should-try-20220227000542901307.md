---
title:  "A sweet Canadian snack you should try…"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/t1_KxpXUo3UqWy_e0lLsmh8F9hvg11FA1NvY44kjdzw.jpg?auto=webp&s=6ebc3d6b67aad7e26471ca590a7af2d695d2b43b"
thumb: "https://external-preview.redd.it/t1_KxpXUo3UqWy_e0lLsmh8F9hvg11FA1NvY44kjdzw.jpg?width=216&crop=smart&auto=webp&s=e407d038404dfd856ea6d45d453d44bf646a573b"
visit: ""
---
A sweet Canadian snack you should try…
