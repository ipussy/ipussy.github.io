---
title:  "Can I rest my legs on your shoulders?"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/9abc90frv6k81.jpg?auto=webp&s=5effde2315ddb97ee150fdebab4a6a62e51d43c0"
thumb: "https://preview.redd.it/9abc90frv6k81.jpg?width=1080&crop=smart&auto=webp&s=71b0c21b626e6e351c383f6d226cc007fa4d23a4"
visit: ""
---
Can I rest my legs on your shoulders?
