---
title:  "Freshly shaved and ready for filling!"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/sbYw4P3s5jhzmtJZcEUa3HP1QNuDlIe8hU5Qm0E-UrE.jpg?auto=webp&s=d7d36acf37d9047386b68fd96cdd23d16f7433d2"
thumb: "https://external-preview.redd.it/sbYw4P3s5jhzmtJZcEUa3HP1QNuDlIe8hU5Qm0E-UrE.jpg?width=1080&crop=smart&auto=webp&s=c49a74fe9f49e604f2d15fb952a03bf32db7af30"
visit: ""
---
Freshly shaved and ready for filling!
