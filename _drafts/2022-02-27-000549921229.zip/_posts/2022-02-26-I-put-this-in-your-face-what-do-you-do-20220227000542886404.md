---
title:  "I put this in your face, what do you do?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/cyJXBcHVZWSbSE8ZntvedjEBNeUn4MV3dkYDsjGdZQU.jpg?auto=webp&s=6a47f76f1a9a6b8a868843d601353b053cfada7e"
thumb: "https://external-preview.redd.it/cyJXBcHVZWSbSE8ZntvedjEBNeUn4MV3dkYDsjGdZQU.jpg?width=1080&crop=smart&auto=webp&s=781ac75a35ccca2a60a434464f7f5778b9366fdb"
visit: ""
---
I put this in your face, what do you do?
