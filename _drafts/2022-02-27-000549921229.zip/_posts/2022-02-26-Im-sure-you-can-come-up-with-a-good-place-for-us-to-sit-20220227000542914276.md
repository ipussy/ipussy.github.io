---
title:  "I’m sure you can come up with a good place for us to sit"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/_zLqUzDw-IFMtH3IXPFW0JOjHUlxtkwttgXhhwHagvE.jpg?auto=webp&s=888fae136a8540d12ea8e806ef3c46aa6f187fb7"
thumb: "https://external-preview.redd.it/_zLqUzDw-IFMtH3IXPFW0JOjHUlxtkwttgXhhwHagvE.jpg?width=216&crop=smart&auto=webp&s=d7f7ab35a6adab8d1415ace2f8bb9d42c8e73221"
visit: ""
---
I’m sure you can come up with a good place for us to sit
