---
title:  "Some Canadian maple syrup for you to sample"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/Hh6ad4FprlXSM8M4eYODDS8R9wz5tjs6XWhwW4vRRUU.jpg?auto=webp&s=a697572550a4d6a9f9c2e0727fd3158d0d83e4c6"
thumb: "https://external-preview.redd.it/Hh6ad4FprlXSM8M4eYODDS8R9wz5tjs6XWhwW4vRRUU.jpg?width=216&crop=smart&auto=webp&s=3bd6dbd4a083a691ba6e224240c8a5a324b9dce2"
visit: ""
---
Some Canadian maple syrup for you to sample
