---
title:  "Freshly shaved! The last thing you see before i sit on your face"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/9lvj972d5lk81.jpg?auto=webp&s=69ab1093f95ee6084789a1a3e00fe256b60eb1ca"
thumb: "https://preview.redd.it/9lvj972d5lk81.jpg?width=1080&crop=smart&auto=webp&s=70e583ddbd76af212f4d1186ab53f3bbe02fa5a8"
visit: ""
---
Freshly shaved! The last thing you see before i sit on your face
