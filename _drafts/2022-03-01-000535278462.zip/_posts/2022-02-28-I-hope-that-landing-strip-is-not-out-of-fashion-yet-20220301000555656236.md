---
title:  "I hope that landing strip is not out of fashion yet"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/txhz44u0nkk81.jpg?auto=webp&s=4f11e3702bc451d8d51539f1bcf3a85b65109e73"
thumb: "https://preview.redd.it/txhz44u0nkk81.jpg?width=1080&crop=smart&auto=webp&s=b18f3a371ffff806712dc5b8c66afeb35dc36e5d"
visit: ""
---
I hope that landing strip is not out of fashion yet
