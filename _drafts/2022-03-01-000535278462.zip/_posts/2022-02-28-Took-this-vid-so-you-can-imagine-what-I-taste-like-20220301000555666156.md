---
title:  "Took this vid so you can imagine what I taste like"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/-46KpO6Iva-u1_9LV3eNJUudfx7_sFG3cRq9OwDRnhc.jpg?auto=webp&s=48f65dde371d8ba8b0db51d35bcd8f4675ca66f3"
thumb: "https://external-preview.redd.it/-46KpO6Iva-u1_9LV3eNJUudfx7_sFG3cRq9OwDRnhc.jpg?width=216&crop=smart&auto=webp&s=74dd70cddac84da8979b8823bdaa8479f73d7c3d"
visit: ""
---
Took this vid so you can imagine what I taste like
