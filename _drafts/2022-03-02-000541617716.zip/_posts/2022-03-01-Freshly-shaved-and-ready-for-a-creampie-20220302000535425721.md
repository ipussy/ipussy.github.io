---
title:  "Freshly shaved and ready for a creampie!"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/cbycrszorsk81.jpg?auto=webp&s=68f995f46f5ca25de6afbff16c87f229f853e838"
thumb: "https://preview.redd.it/cbycrszorsk81.jpg?width=1080&crop=smart&auto=webp&s=47e0ab879bd33abfe326ea2744d302b99bf890aa"
visit: ""
---
Freshly shaved and ready for a creampie!
