---
title:  "The only place my lips should be is on yours"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/sV3wIuQXnlBUyOtXL2yQ5_bMkRV2odYj6nBmI7G2OAk.jpg?auto=webp&s=804fc3eb93993ca446ff953693ad7bfdb354a6bc"
thumb: "https://external-preview.redd.it/sV3wIuQXnlBUyOtXL2yQ5_bMkRV2odYj6nBmI7G2OAk.jpg?width=216&crop=smart&auto=webp&s=cebabccdb9c0bb9c703045308f7abdb2c78b1bed"
visit: ""
---
The only place my lips should be is on yours
