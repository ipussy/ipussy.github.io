---
title:  "Would you lick it first or just slide in?"
metadate: "hide"
categories: [ Rear Pussy ]
image: "https://external-preview.redd.it/V_x3kGq3plFh1Ze6mquFJsamQ6EWYy5F5WeowMIMAqY.jpg?auto=webp&s=374b48989762add58083be5774064cd690f3bbb2"
thumb: "https://external-preview.redd.it/V_x3kGq3plFh1Ze6mquFJsamQ6EWYy5F5WeowMIMAqY.jpg?width=1080&crop=smart&auto=webp&s=64e2eec4b960622a529a8ff9b447d6c669cb28ac"
visit: ""
---
Would you lick it first or just slide in?
