---
title:  "Are petite girls with big boobs your type?"
metadate: "hide"
categories: [ Rear Pussy ]
image: "https://external-preview.redd.it/niVxoqq4dKRs2Z04_JXMM7ujkYVEavYHGuMwugjq1hc.jpg?auto=webp&s=c2b81483dc1930c8201c6e3688ffc0246c6e173e"
thumb: "https://external-preview.redd.it/niVxoqq4dKRs2Z04_JXMM7ujkYVEavYHGuMwugjq1hc.jpg?width=1080&crop=smart&auto=webp&s=0edff3fd0b0cbbeaa1ffe60fb61e55a710d0e499"
visit: ""
---
Are petite girls with big boobs your type?
