---
title:  "Me and my friend wana know which one are you picking ?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/5i1g06xfz2l81.jpg?auto=webp&s=607c66df33015679daca13b4a0cb30550f05b0e0"
thumb: "https://preview.redd.it/5i1g06xfz2l81.jpg?width=1080&crop=smart&auto=webp&s=c1f96fc425792ab6d172fd5c8110daea624adebc"
visit: ""
---
Me and my friend wana know which one are you picking ?
