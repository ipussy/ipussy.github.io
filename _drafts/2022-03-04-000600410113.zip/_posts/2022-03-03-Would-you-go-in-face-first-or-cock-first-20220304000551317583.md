---
title:  "Would you go in face first or cock first?"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/c4l41abkv6l81.jpg?auto=webp&s=a6d2904c76d2d17e880894a36173b1e335d81990"
thumb: "https://preview.redd.it/c4l41abkv6l81.jpg?width=320&crop=smart&auto=webp&s=aacbb0e94933f77636f8efac1e14986b44df456c"
visit: ""
---
Would you go in face first or cock first?
