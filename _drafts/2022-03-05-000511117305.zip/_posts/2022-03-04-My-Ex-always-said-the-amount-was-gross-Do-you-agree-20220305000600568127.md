---
title:  "My Ex always said the amount was gross… Do you agree ? 🙄"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/06XVXyNnfRrmrJjqLfCgSBjNzuvOKCfcyRrTX8jS5HE.jpg?auto=webp&s=9ab181601e861a0cfae6055a229c4395c89b9400"
thumb: "https://external-preview.redd.it/06XVXyNnfRrmrJjqLfCgSBjNzuvOKCfcyRrTX8jS5HE.jpg?width=216&crop=smart&auto=webp&s=dc9fe50227b8ecac992518ae1130da87c600519a"
visit: ""
---
My Ex always said the amount was gross… Do you agree ? 🙄
