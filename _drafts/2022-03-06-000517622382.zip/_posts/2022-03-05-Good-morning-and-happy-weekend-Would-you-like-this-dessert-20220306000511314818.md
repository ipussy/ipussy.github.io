---
title:  "Good morning and happy weekend. Would you like this dessert?"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/pu6SYoH5NWuzEeuMfEc54HXxqcwW60vH-PwUv3i8KWU.jpg?auto=webp&s=ad57154e1ac11ecb50b8a903aad85122fc5c18af"
thumb: "https://external-preview.redd.it/pu6SYoH5NWuzEeuMfEc54HXxqcwW60vH-PwUv3i8KWU.jpg?width=1080&crop=smart&auto=webp&s=91bbf2e78eded15bf719a161b57adc5835849e04"
visit: ""
---
Good morning and happy weekend. Would you like this dessert?
