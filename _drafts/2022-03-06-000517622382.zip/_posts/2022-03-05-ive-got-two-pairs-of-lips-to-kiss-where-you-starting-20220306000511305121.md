---
title:  "ive got two pairs of lips to kiss, where you starting?"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/lg2c6u2r7ll81.jpg?auto=webp&s=085d6ed02a41999a5638f107ef6df12b88a0e831"
thumb: "https://preview.redd.it/lg2c6u2r7ll81.jpg?width=1080&crop=smart&auto=webp&s=48eb2c38964afc9a1faed54ee9b6e8cb16610068"
visit: ""
---
ive got two pairs of lips to kiss, where you starting?
