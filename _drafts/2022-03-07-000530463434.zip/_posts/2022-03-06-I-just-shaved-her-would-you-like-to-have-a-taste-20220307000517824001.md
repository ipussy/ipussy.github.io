---
title:  "I just shaved her, would you like to have a taste?"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/5rcnq96ourl81.jpg?auto=webp&s=8373cd18f8a61ebdfe0d49604ba2c21824cbc56d"
thumb: "https://preview.redd.it/5rcnq96ourl81.jpg?width=1080&crop=smart&auto=webp&s=5ccb8540c523c7e095a890a1111537e427dc2c68"
visit: ""
---
I just shaved her, would you like to have a taste?
