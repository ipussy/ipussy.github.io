---
title:  "I just shaved her, would you like to have a taste?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/y6dePa_xuaVP6U8a71VckBmPaik_vcgfSg30wt09e-Y.jpg?auto=webp&s=18215a5ba6194acbed567eb1f21e3cd265694133"
thumb: "https://external-preview.redd.it/y6dePa_xuaVP6U8a71VckBmPaik_vcgfSg30wt09e-Y.jpg?width=320&crop=smart&auto=webp&s=5f1a8cf7438aa37fb644692c34cdac898e371fb5"
visit: ""
---
I just shaved her, would you like to have a taste?
