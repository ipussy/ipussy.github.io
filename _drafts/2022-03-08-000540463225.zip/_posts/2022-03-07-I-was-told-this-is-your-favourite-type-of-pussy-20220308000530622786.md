---
title:  "I was told this is your favourite type of pussy"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/wR7YisU01fdSnGSsyp38q6YNEGGe1UlBwd7AT8cFtfo.jpg?auto=webp&s=5400cad734fba6da813da54960dc3028f3e500aa"
thumb: "https://external-preview.redd.it/wR7YisU01fdSnGSsyp38q6YNEGGe1UlBwd7AT8cFtfo.jpg?width=216&crop=smart&auto=webp&s=f323772059de508f977840a70d971fa490552b23"
visit: ""
---
I was told this is your favourite type of pussy
