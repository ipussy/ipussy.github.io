---
title:  "I'm the kind of person who's ready for a first date."
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/HVQuYUC4aY9uiSZ4jP0i0DL97OhtTu9n4GKOfsm0ICY.jpg?auto=webp&s=81c1abeb3f64b1c518564e56682de34de609e996"
thumb: "https://external-preview.redd.it/HVQuYUC4aY9uiSZ4jP0i0DL97OhtTu9n4GKOfsm0ICY.jpg?width=1080&crop=smart&auto=webp&s=e3aa6d7a435ee5aed60ed377ed23627dfedc40e0"
visit: ""
---
I'm the kind of person who's ready for a first date.
