---
title:  "It's been around since 1982 but I still think it's holding up well 😃."
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/AYqtebqHj1i3YO13h-nCAb8GiQDEkx8WUowVbyxkSck.jpg?auto=webp&s=ea6a8028e65f6d0d340a99cc89e8d80c308f507e"
thumb: "https://external-preview.redd.it/AYqtebqHj1i3YO13h-nCAb8GiQDEkx8WUowVbyxkSck.jpg?width=1080&crop=smart&auto=webp&s=fa7cd9d83ad1f548b65e7c3dfc45b63beb0ee1d8"
visit: ""
---
It's been around since 1982 but I still think it's holding up well 😃.
