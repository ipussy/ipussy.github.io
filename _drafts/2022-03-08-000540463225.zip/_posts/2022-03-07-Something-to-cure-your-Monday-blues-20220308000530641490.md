---
title:  "Something to cure your Monday blues"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/mh5ukygtkzl81.gif?format=png8&s=b397146906415064a0a5b89de4e80fac51ff1cae"
thumb: "https://preview.redd.it/mh5ukygtkzl81.gif?width=108&crop=smart&format=png8&s=643244fe4bbdcb3090864acbf3041449e30eab99"
visit: ""
---
Something to cure your Monday blues
