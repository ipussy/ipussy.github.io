---
title:  "Would you go for the pussy or asshole first?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/ce7kznxjzul81.jpg?auto=webp&s=b967d323b64ac02e906f641c3e7e224a48d7322b"
thumb: "https://preview.redd.it/ce7kznxjzul81.jpg?width=1080&crop=smart&auto=webp&s=db3e73478fec42ffcaf83541d66e771e87314a87"
visit: ""
---
Would you go for the pussy or asshole first?
