---
title:  "Can I borrow your face ? I promise I’ll be quick"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/W2SOl4fl8GEbWNGDcpaQKkfb45Jo5-RGk1AK5_q9GCw.jpg?auto=webp&s=c80f97a45e5988bf5e332d25d37b9974ac581ff8"
thumb: "https://external-preview.redd.it/W2SOl4fl8GEbWNGDcpaQKkfb45Jo5-RGk1AK5_q9GCw.jpg?width=320&crop=smart&auto=webp&s=5304ef7fbb1131665b350cf4175fd460dbd2a5e7"
visit: ""
---
Can I borrow your face ? I promise I’ll be quick
