---
title:  "Ever tried out a petite Canadian before? If not…what are you waiting for ;)"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/ogDhYqhkxaWBlcnuvPZFsvpX5PPePd51LiVYHm9Sv_A.jpg?auto=webp&s=0de9ce724298f35996e795ba5c22cd5a1d8007a7"
thumb: "https://external-preview.redd.it/ogDhYqhkxaWBlcnuvPZFsvpX5PPePd51LiVYHm9Sv_A.jpg?width=640&crop=smart&auto=webp&s=e48ccae258a516aff7769bf95ca613fb8c196a98"
visit: ""
---
Ever tried out a petite Canadian before? If not…what are you waiting for ;)
