---
title:  "Let's play truth or action, I choose action! What will you wish for me?"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/TJOTGgFXzBW4-xPUusV2yz4jWEg5swL0uv0Rsge8Arc.jpg?auto=webp&s=047dd37ed1db66036df0044ed3aa5714cd3c6c2a"
thumb: "https://external-preview.redd.it/TJOTGgFXzBW4-xPUusV2yz4jWEg5swL0uv0Rsge8Arc.jpg?width=1080&crop=smart&auto=webp&s=1234a8dd5d456ed5fa8a8dc6037c672bc3ba8651"
visit: ""
---
Let's play "truth or action", I choose action! What will you wish for me?
