---
title:  "which shade of pink is prettier to you, my shirt or my pussy?"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/lz8k5lt1i6m81.jpg?auto=webp&s=34b40a95c0964f2fba9a60ac6bd82e3f206166f1"
thumb: "https://preview.redd.it/lz8k5lt1i6m81.jpg?width=1080&crop=smart&auto=webp&s=fcf8353f5a80daf2ee35e79f158c192761b0f8ab"
visit: ""
---
which shade of pink is prettier to you, my shirt or my pussy?
