---
title:  "Freshly waxed perfect for your tongue"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/dat4g5pczdm81.jpg?auto=webp&s=b6157209ece02798fe08703a69abf794f85714a3"
thumb: "https://preview.redd.it/dat4g5pczdm81.jpg?width=640&crop=smart&auto=webp&s=3c7df453fa6f9c96805f812e335d7c543a95035c"
visit: ""
---
Freshly waxed perfect for your tongue
