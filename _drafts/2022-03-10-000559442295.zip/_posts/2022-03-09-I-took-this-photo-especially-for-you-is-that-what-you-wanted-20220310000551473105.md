---
title:  "I took this photo especially for you, is that what you wanted?"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/q3u0vxnTTQHDNI0LvriVSM5apNijrfaIbiGaLzOpUuo.jpg?auto=webp&s=04b77037e83b19628f52eae5390ca13fda44bc4a"
thumb: "https://external-preview.redd.it/q3u0vxnTTQHDNI0LvriVSM5apNijrfaIbiGaLzOpUuo.jpg?width=1080&crop=smart&auto=webp&s=299e0e7fd8fbf3b9d823c2f3b7511f6e10b3efde"
visit: ""
---
I took this photo especially for you, is that what you wanted?
