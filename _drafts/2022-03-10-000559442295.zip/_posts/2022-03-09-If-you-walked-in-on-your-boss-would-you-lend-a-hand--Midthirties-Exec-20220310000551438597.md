---
title:  "If you walked in on your boss, would you lend a hand? 😽 (Mid-thirties Exec)"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/Nt9_Z_EEF_wrBi2l3gHVvNqm2Pckwk1pWJnf5QLMK8I.jpg?auto=webp&s=30a90d23ff88bcf3df0ffddf075f458d5b4590c8"
thumb: "https://external-preview.redd.it/Nt9_Z_EEF_wrBi2l3gHVvNqm2Pckwk1pWJnf5QLMK8I.jpg?width=320&crop=smart&auto=webp&s=ad2524e7df824c05410c8e9d223751568afda828"
visit: ""
---
If you walked in on your boss, would you lend a hand? 😽 (Mid-thirties Exec)
