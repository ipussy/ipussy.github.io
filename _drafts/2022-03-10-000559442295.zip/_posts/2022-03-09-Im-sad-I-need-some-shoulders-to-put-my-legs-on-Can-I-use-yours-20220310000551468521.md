---
title:  "I'm sad, I need some shoulders to put my legs on. Can I use yours?"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/LCqFwAi1daGpa8PpuM5JT2Lq43D3tYz6E5Abd7UbOcM.jpg?auto=webp&s=7b1cb13f68e7ebfc4104d9e511c290f6b1e61688"
thumb: "https://external-preview.redd.it/LCqFwAi1daGpa8PpuM5JT2Lq43D3tYz6E5Abd7UbOcM.jpg?width=640&crop=smart&auto=webp&s=30921345087649972899638caf675eb0924d7b8f"
visit: ""
---
I'm sad, I need some shoulders to put my legs on. Can I use yours?
