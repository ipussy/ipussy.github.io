---
title:  "if i’m your type, can we be fuck buddies?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/Uivi-3nSS6QZ-NeVaKmppxqvHdjUXxeuwWVPm7lXyqE.jpg?auto=webp&s=3ec1cbafa09d2482a418395a017ffd6144e0cc05"
thumb: "https://external-preview.redd.it/Uivi-3nSS6QZ-NeVaKmppxqvHdjUXxeuwWVPm7lXyqE.jpg?width=216&crop=smart&auto=webp&s=cfbfade2763f1ac60e6204d923991032c2324c0b"
visit: ""
---
if i’m your type, can we be fuck buddies?
