---
title:  "Have you ever broken in a flexible Canadian before ?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/q1uu7c8rmhm81.jpg?auto=webp&s=69535ce3f1c4427dfd0014d0c8c79f289ffb59b7"
thumb: "https://preview.redd.it/q1uu7c8rmhm81.jpg?width=640&crop=smart&auto=webp&s=bce771f59cea972a168a22996a294c55d7041560"
visit: ""
---
Have you ever broken in a flexible Canadian before ?
