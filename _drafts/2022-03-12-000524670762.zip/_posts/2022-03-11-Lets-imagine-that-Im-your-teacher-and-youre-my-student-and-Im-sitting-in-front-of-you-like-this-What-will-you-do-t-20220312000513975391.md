---
title:  "Let's imagine that I'm your teacher, and you're my student, and I'm sitting in front of you like this! What will you do to me first?"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/awQh8pjqxOJRL6rfWK5joBICcXspCFgo7RpEM3J2bA0.jpg?auto=webp&s=a2561bdd168556415dee52beddf25761d0e469b5"
thumb: "https://external-preview.redd.it/awQh8pjqxOJRL6rfWK5joBICcXspCFgo7RpEM3J2bA0.jpg?width=1080&crop=smart&auto=webp&s=de5e19f822d832288c0669870e34548edd2b2916"
visit: ""
---
Let's imagine that I'm your teacher, and you're my student, and I'm sitting in front of you like this! What will you do to me first?
