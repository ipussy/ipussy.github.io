---
title:  "Santa called and said Christmas is coming early this year"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/L3Y1tx7Z2HFL1phtp-a3erMpG_R8_FYGyvFk0lXgYos.jpg?auto=webp&s=59dba8a2a9dc09e8b67a605b322aeef6a2c1e6e0"
thumb: "https://external-preview.redd.it/L3Y1tx7Z2HFL1phtp-a3erMpG_R8_FYGyvFk0lXgYos.jpg?width=216&crop=smart&auto=webp&s=a0f8592d14b0169d9d01d658a07521f26d9f4293"
visit: ""
---
Santa called and said Christmas is coming early this year
