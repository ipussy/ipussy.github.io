---
title:  "The sun is warm when I’m freshly shaved"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/t4gco86fmom81.jpg?auto=webp&s=bb8ab7d3cf3d092572bff1d2acfd9fb9c652a5d7"
thumb: "https://preview.redd.it/t4gco86fmom81.jpg?width=1080&crop=smart&auto=webp&s=d79d1a3ec95666b6c1a4855d9c8aa2839ca67809"
visit: ""
---
The sun is warm when I’m freshly shaved
