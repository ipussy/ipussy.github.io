---
title:  "Thought I should treat you and open the gates of heaven"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/31k9KBMwn9zwy0v669vOIzpQnNkA7ddDA5EP7SZKfZk.jpg?auto=webp&s=3420a3d91c55fc6dc58e752f62dae9b5785865c9"
thumb: "https://external-preview.redd.it/31k9KBMwn9zwy0v669vOIzpQnNkA7ddDA5EP7SZKfZk.jpg?width=216&crop=smart&auto=webp&s=8eb4c5bc5086a5039e1d71c078f2a8ed97c53316"
visit: ""
---
Thought I should treat you and open the gates of heaven
