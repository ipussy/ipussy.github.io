---
title:  "Would you ride a note of this historical day that you are witnessing now? :P"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/2SvgY9xlB5dBcUlu5xx0IE_-DD28FNtYMcuNlPMvB2I.jpg?auto=webp&s=825ac4c475368c60f2958726a5432de961abc859"
thumb: "https://external-preview.redd.it/2SvgY9xlB5dBcUlu5xx0IE_-DD28FNtYMcuNlPMvB2I.jpg?width=320&crop=smart&auto=webp&s=8d00be6c542e07cd1e0e16473346f75e339480c2"
visit: ""
---
Would you ride a note of this historical day that you are witnessing now? :P
