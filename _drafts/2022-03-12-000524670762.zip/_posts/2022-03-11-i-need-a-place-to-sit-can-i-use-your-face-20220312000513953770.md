---
title:  "i need a place to sit, can i use your face?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/1ZV55yRbQgH-IzMgxgTe8bn_CBaF-K3ZYrQIpbsMz2k.jpg?auto=webp&s=f905ba8ce1c584bda06e23d2dcf0f66521090b53"
thumb: "https://external-preview.redd.it/1ZV55yRbQgH-IzMgxgTe8bn_CBaF-K3ZYrQIpbsMz2k.jpg?width=216&crop=smart&auto=webp&s=5c920ca7164c5fff7124d876852b35f53d20e631"
visit: ""
---
i need a place to sit, can i use your face?
