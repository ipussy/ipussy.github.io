---
title:  "I love how wet I get after getting waxed"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/gt1xlby6azm81.jpg?auto=webp&s=fea4c8999e05efae6c7199238db01e3368c126fa"
thumb: "https://preview.redd.it/gt1xlby6azm81.jpg?width=640&crop=smart&auto=webp&s=ba60b2577f0c8b682fbc797eaff4dbf7bf2efa33"
visit: ""
---
I love how wet I get after getting waxed
