---
title:  "Female 33 - bull wanted 2x weekends. Hubby approves. Clean HW - serious men only. Will also swing with couples when husband home. No time wasters. Serious post as I have needs and need them accommodating. Will support travel for successful candidate. X"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/mjloyah9g6n81.jpg?auto=webp&s=b11adf3c2b14ba1243e2ac65c6750dacbd156f08"
thumb: "https://preview.redd.it/mjloyah9g6n81.jpg?width=1080&crop=smart&auto=webp&s=ad3afc8fbc3f6d78d018ed0c08880eb36b7d6315"
visit: ""
---
Female 33 - bull wanted 2x weekends. Hubby approves. Clean HW - serious men only. Will also swing with couples when husband home. No time wasters. Serious post as I have needs and need them accommodating. Will support travel for successful candidate. X
