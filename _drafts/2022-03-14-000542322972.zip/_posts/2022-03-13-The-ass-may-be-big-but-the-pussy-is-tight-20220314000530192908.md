---
title:  "The ass may be big, but the pussy is tight."
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/_2KBsuv494O71CIMhw4mNKVDU4N80KjK-Fpw2NY3E_0.jpg?auto=webp&s=9a713b2319eb22e53941c08535ce8379f81235b3"
thumb: "https://external-preview.redd.it/_2KBsuv494O71CIMhw4mNKVDU4N80KjK-Fpw2NY3E_0.jpg?width=640&crop=smart&auto=webp&s=271d394e46504df3fd3a03f860684b9ad969f729"
visit: ""
---
The ass may be big, but the pussy is tight.
