---
title:  "White socks have a bad rep and for what?"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/jwvv0p3ee6n81.jpg?auto=webp&s=ab0089c30f2d5e31d0c62d8ae639751a820483bf"
thumb: "https://preview.redd.it/jwvv0p3ee6n81.jpg?width=1080&crop=smart&auto=webp&s=4edc6ed281cd9662773992fc726d3f1d59ced30a"
visit: ""
---
White socks have a bad rep and for what?
