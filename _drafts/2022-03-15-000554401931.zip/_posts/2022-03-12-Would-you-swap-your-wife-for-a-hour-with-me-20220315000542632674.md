---
title:  "Would you swap your wife for a hour with me?"
metadate: "hide"
categories: [ Rear Pussy ]
image: "https://external-preview.redd.it/jBXsXix-VSXw_Z0BEC0-h-6LcGwYNR040iNY_wAZ0UM.jpg?auto=webp&s=0a50fd81684453c7378a8b9a3b0fabdf11c8f69c"
thumb: "https://external-preview.redd.it/jBXsXix-VSXw_Z0BEC0-h-6LcGwYNR040iNY_wAZ0UM.jpg?width=1080&crop=smart&auto=webp&s=df13c9c3f09dec4defa3294bc99a7b10c1b41df3"
visit: ""
---
Would you swap your wife for a hour with me?
