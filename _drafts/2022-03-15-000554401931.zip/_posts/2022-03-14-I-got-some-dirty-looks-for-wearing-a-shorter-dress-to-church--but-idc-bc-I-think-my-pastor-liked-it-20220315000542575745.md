---
title:  "I got some dirty looks for wearing a shorter dress to church 🙄 but idc bc I think my pastor liked it 🙈💕"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/nakvdtjod8n81.jpg?auto=webp&s=37c2696c9d0be2b2d54560081bf1061569f89db9"
thumb: "https://preview.redd.it/nakvdtjod8n81.jpg?width=1080&crop=smart&auto=webp&s=e498ca68e88467606f1fe6333e925638274baa9c"
visit: ""
---
I got some dirty looks for wearing a shorter dress to church 🙄 but idc bc I think my pastor liked it 🙈💕
