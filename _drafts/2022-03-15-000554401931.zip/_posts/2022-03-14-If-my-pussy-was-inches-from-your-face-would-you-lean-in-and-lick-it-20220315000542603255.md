---
title:  "If my pussy was inches from your face, would you lean in and lick it?"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/B0yqupFAciKM8PWv6BRmlzUhAv9GH44wWXtNtl8rQIg.jpg?auto=webp&s=fc4641943558e9e0c9c12929a3d720af65e0f2d2"
thumb: "https://external-preview.redd.it/B0yqupFAciKM8PWv6BRmlzUhAv9GH44wWXtNtl8rQIg.jpg?width=1080&crop=smart&auto=webp&s=0aa70e1afb8d96ded739a90ee8ba6f26c4830d50"
visit: ""
---
If my pussy was inches from your face, would you lean in and lick it?
