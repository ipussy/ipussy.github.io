---
title:  "In honor of Pi day, here is my wife’s cream pie 🥧 (OC)"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/lozacr1xjdn81.jpg?auto=webp&s=3bb266e3b2a945bfbe0e4eddc617121c514c53f4"
thumb: "https://preview.redd.it/lozacr1xjdn81.jpg?width=1080&crop=smart&auto=webp&s=1ab251b23b578e3699a2d1ccf10a61125a2c6791"
visit: ""
---
In honor of Pi day, here is my wife’s cream pie 🥧 (OC)
