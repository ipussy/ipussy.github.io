---
title:  "I need a place to rest my legs, maybe your shoulders?"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/F_t8d5i_qdJ2yh0Rp_9CsX8BueHOflE5SNQ_7E7yHro.jpg?auto=webp&s=8d245b2714defa601a64c388794bf668ebb1f6e2"
thumb: "https://external-preview.redd.it/F_t8d5i_qdJ2yh0Rp_9CsX8BueHOflE5SNQ_7E7yHro.jpg?width=1080&crop=smart&auto=webp&s=f04d58ccc4671936324cb1a8d4c9e77f1185bd40"
visit: ""
---
I need a place to rest my legs, maybe your shoulders?
