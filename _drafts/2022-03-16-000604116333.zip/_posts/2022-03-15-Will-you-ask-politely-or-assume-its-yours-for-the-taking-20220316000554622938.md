---
title:  "Will you ask politely or assume it's yours for the taking? 😈"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/Xky6yEGZN8V2F_1wl2tiHLvWo5Qh0ug5cF3qY0yqUho.jpg?auto=webp&s=9a30150361150b8a08f72b908375ae1aa2f8a198"
thumb: "https://external-preview.redd.it/Xky6yEGZN8V2F_1wl2tiHLvWo5Qh0ug5cF3qY0yqUho.jpg?width=320&crop=smart&auto=webp&s=8b4f5a529e1e0a36491ebfd211f3e57ce1961dc3"
visit: ""
---
Will you ask politely or assume it's yours for the taking? 😈
