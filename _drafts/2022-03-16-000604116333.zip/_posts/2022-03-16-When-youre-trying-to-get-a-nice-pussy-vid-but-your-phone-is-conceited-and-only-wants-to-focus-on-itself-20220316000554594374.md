---
title:  "When you’re trying to get a nice pussy vid but your phone is conceited and only wants to focus on itself…"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/BttDQWG71HwZQ4YiUrIqnRbMNMins65k3oWarq_A5bI.jpg?auto=webp&s=6a84766edb67be851167c80e966add49809db6b1"
thumb: "https://external-preview.redd.it/BttDQWG71HwZQ4YiUrIqnRbMNMins65k3oWarq_A5bI.jpg?width=216&crop=smart&auto=webp&s=327a7caafb2d4d85d411c2784547b4084d0d1d6d"
visit: ""
---
When you’re trying to get a nice pussy vid but your phone is conceited and only wants to focus on itself…
