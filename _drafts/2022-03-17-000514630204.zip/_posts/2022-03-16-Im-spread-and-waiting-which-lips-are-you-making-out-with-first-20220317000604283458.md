---
title:  "I'm spread and waiting... which lips are you making out with first?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/KioWjY4_EuXlgjm_peCZDbW7U5ohv-MSfJig9EzxYSo.jpg?auto=webp&s=217ec6c30b955c9b9f51e35a88cbd5b82c9147ac"
thumb: "https://external-preview.redd.it/KioWjY4_EuXlgjm_peCZDbW7U5ohv-MSfJig9EzxYSo.jpg?width=1080&crop=smart&auto=webp&s=1e46d80308d9d4edc14b9d3d5f093e8ec7e16087"
visit: ""
---
I'm spread and waiting... which lips are you making out with first?
