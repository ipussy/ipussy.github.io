---
title:  "freshly shaved, felt like showing off"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/0TRtd3nQYPzDT695vv45N59BwYzsAePpOaESjjGjdT4.jpg?auto=webp&s=b0ccb4520396fd67ecf3ddc10cb90f3eccd2f6c4"
thumb: "https://external-preview.redd.it/0TRtd3nQYPzDT695vv45N59BwYzsAePpOaESjjGjdT4.jpg?width=216&crop=smart&auto=webp&s=8755d0c848f68caa1a9b906a7ec9939850e9ace5"
visit: ""
---
freshly shaved, felt like showing off
