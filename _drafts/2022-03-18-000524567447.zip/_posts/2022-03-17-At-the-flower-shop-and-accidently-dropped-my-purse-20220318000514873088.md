---
title:  "At the flower shop and accidently dropped my purse"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/bL6QgCC8DaDPRMa8AX--4RHtf1CiHq5VHRekzOchvBY.png?auto=webp&s=434921e74cc51b9c43262207d0beff95c31ca2f0"
thumb: "https://external-preview.redd.it/bL6QgCC8DaDPRMa8AX--4RHtf1CiHq5VHRekzOchvBY.png?width=320&crop=smart&auto=webp&s=33929a2ba2993554e57686764adb60f20bd866e0"
visit: ""
---
At the flower shop and "accidently" dropped my purse
