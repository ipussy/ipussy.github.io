---
title:  "I wonder if you can guess what the inspiration for my nail color was!"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/m-AgQd365DT3zbSWujglVSEk5HdkSGnbGEzgLpExKfA.jpg?auto=webp&s=ad9933cf5ae83b9b959aac81ede98504ca793475"
thumb: "https://external-preview.redd.it/m-AgQd365DT3zbSWujglVSEk5HdkSGnbGEzgLpExKfA.jpg?width=216&crop=smart&auto=webp&s=93bb1d265a753fdac3587bb1810a54a6ddfd8f0c"
visit: ""
---
I wonder if you can guess what the inspiration for my nail color was!
