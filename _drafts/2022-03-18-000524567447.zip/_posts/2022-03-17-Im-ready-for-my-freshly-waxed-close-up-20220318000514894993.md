---
title:  "I’m ready for my freshly waxed close up."
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/00z32px0ryn81.jpg?auto=webp&s=bbd8dd50ed86721b7e2777322ab53b0f2107f9b7"
thumb: "https://preview.redd.it/00z32px0ryn81.jpg?width=1080&crop=smart&auto=webp&s=073377c97c4181f851fe518ef9f551f6059bfcc3"
visit: ""
---
I’m ready for my freshly waxed close up.
