---
title:  "I assumed the position, now it’s your turn"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/LigOtfh6LDf9I3XD9YsrdHWMdOQSUpEHE2b5-GehT14.jpg?auto=webp&s=742c33322d2fd181176d4126baa2031f63ceaaf8"
thumb: "https://external-preview.redd.it/LigOtfh6LDf9I3XD9YsrdHWMdOQSUpEHE2b5-GehT14.jpg?width=216&crop=smart&auto=webp&s=4bbab7c29d9cc57b9adfd424cd8133cf29be702c"
visit: ""
---
I assumed the position, now it’s your turn
