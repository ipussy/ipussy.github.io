---
title:  "What kind, of course, can you teach me, professor? :P"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/qrlRPtKdNdK5wzkDBQQU92wSmjXb8uybetxaYs-Ikjw.jpg?auto=webp&s=f92ecbf9a60902d42064c898e828e53f17ec9c48"
thumb: "https://external-preview.redd.it/qrlRPtKdNdK5wzkDBQQU92wSmjXb8uybetxaYs-Ikjw.jpg?width=640&crop=smart&auto=webp&s=0f89bc0975fb5259a95e171caa0e46d4949f1704"
visit: ""
---
What kind, of course, can you teach me, professor? :P
