---
title:  "What's the first action u take if u see me like this in ur bed?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/plEmmc6lqWkRQzXoRfDTqaCG9SeTMtAbg9vy9oqiqtM.jpg?auto=webp&s=e4fec1b1f73066b38fda3554357e303cd67a4db1"
thumb: "https://external-preview.redd.it/plEmmc6lqWkRQzXoRfDTqaCG9SeTMtAbg9vy9oqiqtM.jpg?width=216&crop=smart&auto=webp&s=4631a001051b238eb276bae87efdbef494b337f9"
visit: ""
---
What's the first action u take if u see me like this in ur bed?
