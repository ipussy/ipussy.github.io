---
title:  "Would you lick it clean if I sit on your face?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/eWCH9rEMSKZ0Wkn1y2XwN8_0p5oy6zwfSI4NPem9NFE.jpg?auto=webp&s=5faac6c0010ee17d2580253cb473d8b804ea3fd2"
thumb: "https://external-preview.redd.it/eWCH9rEMSKZ0Wkn1y2XwN8_0p5oy6zwfSI4NPem9NFE.jpg?width=320&crop=smart&auto=webp&s=be05e624410c78c65043ff6f68f7e5db814cc08e"
visit: ""
---
Would you lick it clean if I sit on your face?
