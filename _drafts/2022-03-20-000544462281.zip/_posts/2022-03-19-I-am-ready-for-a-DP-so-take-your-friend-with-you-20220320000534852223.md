---
title:  "I am ready for a DP, so take your friend with you"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/d7871z0sk7o81.jpg?auto=webp&s=32637eb79a5356952cc37036c25ccb614f5b3a52"
thumb: "https://preview.redd.it/d7871z0sk7o81.jpg?width=1080&crop=smart&auto=webp&s=61151a0cbd22c3478250cd7fa8a45dd878e5d3a4"
visit: ""
---
I am ready for a DP, so take your friend with you
