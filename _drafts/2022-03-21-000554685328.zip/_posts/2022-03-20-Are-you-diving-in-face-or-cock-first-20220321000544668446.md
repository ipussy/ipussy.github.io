---
title:  "Are you diving in face or cock first?"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/c58509z3cko81.jpg?auto=webp&s=8d462ed63421182b4ec6e5df09dfcf65c1eab376"
thumb: "https://preview.redd.it/c58509z3cko81.jpg?width=1080&crop=smart&auto=webp&s=938ed1639a86c0da57ab6235336c2761042c6057"
visit: ""
---
Are you diving in face or cock first?
