---
title:  "I have a ripe little strawberry here waiting for you!"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/q6p9x0dWVp5IQXUQIpldTL91ZkP0s6WPIdz4KbtOtvE.jpg?auto=webp&s=c9c0c3eaafd8fbdef915ac95d1f89dcea63b18f0"
thumb: "https://external-preview.redd.it/q6p9x0dWVp5IQXUQIpldTL91ZkP0s6WPIdz4KbtOtvE.jpg?width=640&crop=smart&auto=webp&s=8dae0d173dff694109dd9fb0221ac29aab99bda7"
visit: ""
---
I have a ripe little strawberry here waiting for you!
