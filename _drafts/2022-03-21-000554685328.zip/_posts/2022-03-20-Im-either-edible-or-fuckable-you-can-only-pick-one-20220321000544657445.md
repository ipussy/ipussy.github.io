---
title:  "I’m either edible or fuckable, you can only pick one."
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/yjmk8ew9reo81.jpg?auto=webp&s=5085c8053182bfdd24ea4f199e0b15750c20906a"
thumb: "https://preview.redd.it/yjmk8ew9reo81.jpg?width=1080&crop=smart&auto=webp&s=945925eb064778e25e7bc2cacbd314e1fa052f86"
visit: ""
---
I’m either edible or fuckable, you can only pick one.
