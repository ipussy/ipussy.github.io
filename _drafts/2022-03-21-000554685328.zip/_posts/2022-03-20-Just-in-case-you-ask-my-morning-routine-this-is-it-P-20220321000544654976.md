---
title:  "Just in case you ask my morning routine, this is it :P"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/QcJzuuwdjYl0f1ZkhAznqTtAW2MFdGGqFfhgnjPkr7Q.jpg?auto=webp&s=d0e2da1effdaba91f44e8f7c3738768beabd20d7"
thumb: "https://external-preview.redd.it/QcJzuuwdjYl0f1ZkhAznqTtAW2MFdGGqFfhgnjPkr7Q.jpg?width=320&crop=smart&auto=webp&s=9dafe29654dae2e1650e1e25b048b6bcdeaec9a7"
visit: ""
---
Just in case you ask my morning routine, this is it :P
