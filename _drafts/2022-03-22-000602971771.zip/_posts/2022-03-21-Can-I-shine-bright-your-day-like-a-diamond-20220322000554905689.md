---
title:  "Can I shine bright your day like a diamond ? :*"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/7GGmZar5OoBZ16w6-wCVG25iYB5cpcYJLpw-qVvGieI.jpg?auto=webp&s=b93cd4b3b60b0b5274c499449ca6c52631bd1c5a"
thumb: "https://external-preview.redd.it/7GGmZar5OoBZ16w6-wCVG25iYB5cpcYJLpw-qVvGieI.jpg?width=1080&crop=smart&auto=webp&s=84e8180704bd06dd5ef7e8051c4d636306a957d5"
visit: ""
---
Can I shine bright your day like a diamond ? :*
