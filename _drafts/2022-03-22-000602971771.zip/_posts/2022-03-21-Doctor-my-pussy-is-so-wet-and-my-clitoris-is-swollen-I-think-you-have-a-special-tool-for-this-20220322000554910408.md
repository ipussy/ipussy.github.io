---
title:  "Doctor, my pussy is so wet and my clitoris is swollen.. I think you have a special tool for this!"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/mxeXOXKsvd6nosJVPt2jDH-h764vdttgHdvZax81jCY.jpg?auto=webp&s=3b961b87d2d1577f488741d681e6c6bb7fed1ca9"
thumb: "https://external-preview.redd.it/mxeXOXKsvd6nosJVPt2jDH-h764vdttgHdvZax81jCY.jpg?width=1080&crop=smart&auto=webp&s=3ebd6d72422e2d4bca3464cb1352f84d28e69394"
visit: ""
---
Doctor, my pussy is so wet and my clitoris is swollen.. I think you have a special tool for this!
