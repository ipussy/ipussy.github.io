---
title:  "Hopefully i can make you bust as hard as Kentucky made my bracket bust"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/Ymteifz9mGcGzDfgyghTzWMdtll7g-A4OhrCZGM5a-w.jpg?auto=webp&s=d5ef6bb59b27eeeca622ea53f35a4369cd936330"
thumb: "https://external-preview.redd.it/Ymteifz9mGcGzDfgyghTzWMdtll7g-A4OhrCZGM5a-w.jpg?width=320&crop=smart&auto=webp&s=8e74afb6ed14884b003c4385f06cb90fbb7f374b"
visit: ""
---
Hopefully i can make you bust as hard as Kentucky made my bracket bust
