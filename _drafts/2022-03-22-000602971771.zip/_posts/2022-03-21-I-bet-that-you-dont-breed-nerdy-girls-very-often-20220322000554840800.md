---
title:  "I bet that you don’t breed nerdy girls very often"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/jXbykNaHKhkBcgYZJ73dhiegNC_CY8Nbkl4RM83KXYQ.jpg?auto=webp&s=2eb6898950a9cb7d9106f293c02d750ca4fa06dd"
thumb: "https://external-preview.redd.it/jXbykNaHKhkBcgYZJ73dhiegNC_CY8Nbkl4RM83KXYQ.jpg?width=640&crop=smart&auto=webp&s=141ad40b227ae5006373c5b6b871ed22c855ebae"
visit: ""
---
I bet that you don’t breed nerdy girls very often
