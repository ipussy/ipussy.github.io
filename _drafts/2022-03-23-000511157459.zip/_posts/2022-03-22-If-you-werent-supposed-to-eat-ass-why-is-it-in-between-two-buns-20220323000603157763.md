---
title:  "If you weren’t supposed to eat ass.. why is it in between two buns?"
metadate: "hide"
categories: [ Rear Pussy ]
image: "https://external-preview.redd.it/cJLe4AnOtU2NxiYB4DreRgDxvstTFmgnGMDx07nDIJU.jpg?auto=webp&s=2195170a71d4e7c2d047d95a2343172e74df9ada"
thumb: "https://external-preview.redd.it/cJLe4AnOtU2NxiYB4DreRgDxvstTFmgnGMDx07nDIJU.jpg?width=320&crop=smart&auto=webp&s=ed069f9134494fa0884dfa389b84170de78b4ac9"
visit: ""
---
If you weren’t supposed to eat ass.. why is it in between two buns?
