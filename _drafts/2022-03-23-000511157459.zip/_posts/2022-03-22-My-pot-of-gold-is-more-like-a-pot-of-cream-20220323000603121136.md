---
title:  "My pot of gold is more like a pot of cream"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/o45gzrilpto81.jpg?auto=webp&s=7c2d457197fb5ee9422a8263f11dd7c44fe32c37"
thumb: "https://preview.redd.it/o45gzrilpto81.jpg?width=1080&crop=smart&auto=webp&s=eee636291c0f0dc0cbad776851bc49ba9c8fbb30"
visit: ""
---
My pot of gold is more like a pot of cream
