---
title:  "where are you putting your tongue first?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/xoXDu9JvuqKjEsnAbPrwO9UH783A6I_NDrpL6Bja9cw.jpg?auto=webp&s=b29ed7c0081bedd9d77a7a2b67a3e86d2738d0da"
thumb: "https://external-preview.redd.it/xoXDu9JvuqKjEsnAbPrwO9UH783A6I_NDrpL6Bja9cw.jpg?width=1080&crop=smart&auto=webp&s=97a7a561d476b13f317746c35c8bdd3cd0e74034"
visit: ""
---
where are you putting your tongue first?
