---
title:  "I just took a shower…but I need a tongue bath from you!"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/tNoR3zF5O-LKQCQnlHJYl4FM9uFmCOMDTsPEjV-j2lM.jpg?auto=webp&s=62b4f79dc0de1077df6b126ee877d6e27b678188"
thumb: "https://external-preview.redd.it/tNoR3zF5O-LKQCQnlHJYl4FM9uFmCOMDTsPEjV-j2lM.jpg?width=216&crop=smart&auto=webp&s=91d3283e1f6cd9f3836419256b842f4c72654e6c"
visit: ""
---
I just took a shower…but I need a tongue bath from you!
