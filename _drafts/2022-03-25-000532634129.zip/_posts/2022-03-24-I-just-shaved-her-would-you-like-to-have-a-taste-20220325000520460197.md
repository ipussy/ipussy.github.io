---
title:  "I just shaved her, would you like to have a taste?"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/iupj53g62cp81.jpg?auto=webp&s=89d97d98809854a2098162812c82f0b3824af201"
thumb: "https://preview.redd.it/iupj53g62cp81.jpg?width=1080&crop=smart&auto=webp&s=392f484e89ab4ab39d394b2411d5cbe24b9ee38e"
visit: ""
---
I just shaved her, would you like to have a taste?
