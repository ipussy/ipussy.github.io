---
title:  "Would you taste my thighs or my wings first?"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/q0qt3ua1gcp81.jpg?auto=webp&s=7aa836c3c017b663a74095a55acca0ce5a388ff1"
thumb: "https://preview.redd.it/q0qt3ua1gcp81.jpg?width=1080&crop=smart&auto=webp&s=9a61c8a49fc1616c7d32b1493dd6c3af04ccbd92"
visit: ""
---
Would you taste my thighs or my wings first?
