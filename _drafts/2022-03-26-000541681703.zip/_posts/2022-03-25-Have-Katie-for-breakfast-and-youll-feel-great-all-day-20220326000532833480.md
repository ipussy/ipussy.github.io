---
title:  "Have Katie for breakfast and you’ll feel great all day"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/RE7jins1kqo2pqOIske9bJp21c2QUC5Iiwr7q72VXJY.gif?format=png8&s=42466c2e562d8071e788e910307b9b6befd1deb3"
thumb: "https://external-preview.redd.it/RE7jins1kqo2pqOIske9bJp21c2QUC5Iiwr7q72VXJY.gif?width=640&crop=smart&format=png8&s=93b1dd0a985c977cace0e921fd1bbe91828c4077"
visit: ""
---
Have Katie for breakfast and you’ll feel great all day
