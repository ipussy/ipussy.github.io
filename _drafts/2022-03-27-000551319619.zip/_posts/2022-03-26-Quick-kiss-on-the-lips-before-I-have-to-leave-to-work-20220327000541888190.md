---
title:  "Quick kiss on the lips before I have to leave to work?;)"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/p4umyqsuuqp81.jpg?auto=webp&s=9b76a96674bb17c7bd1e71a68054b18c75cfa7f2"
thumb: "https://preview.redd.it/p4umyqsuuqp81.jpg?width=1080&crop=smart&auto=webp&s=1e609dc48d11be4bbb09f4a520f2f4ee12b13c63"
visit: ""
---
Quick kiss on the lips before I have to leave to work?;)
