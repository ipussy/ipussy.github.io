---
title:  "Can’t buy alcohol but I sure can can take dick"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/GbMFyZHwAc4OZP3DTsjFhbUqY8RDC1J83D-WB2QBWkE.jpg?auto=webp&s=430224793c4182e20a58fc6f86e65a54852eb78a"
thumb: "https://external-preview.redd.it/GbMFyZHwAc4OZP3DTsjFhbUqY8RDC1J83D-WB2QBWkE.jpg?width=216&crop=smart&auto=webp&s=89b2eb5248861f0c45401b75b0d645b867ed48d4"
visit: ""
---
Can’t buy alcohol but I sure can can take dick
