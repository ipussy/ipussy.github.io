---
title:  "Hey Reddit! I’m brand new here and nervous as hell lol I’m looking for a bull when my hubbie is away 2x a month, will have to be comfortable being filmed so I can send to him. No kids and will provide bed for the night x"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/x7myo54g4yp81.jpg?auto=webp&s=4c7aa3052c4ed2973112d51ce0e9c5219d661a87"
thumb: "https://preview.redd.it/x7myo54g4yp81.jpg?width=1080&crop=smart&auto=webp&s=386f4569509352040ea7f4259574e46cb5926ec0"
visit: ""
---
Hey Reddit! I’m brand new here and nervous as hell lol I’m looking for a bull when my hubbie is away 2x a month, will have to be comfortable being filmed so I can send to him. No kids and will provide bed for the night x
