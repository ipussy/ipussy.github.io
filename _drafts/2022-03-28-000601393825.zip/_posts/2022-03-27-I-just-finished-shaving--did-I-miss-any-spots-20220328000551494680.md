---
title:  "I just finished shaving - did I miss any spots?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/kSMssYYqIgWRJYepLyHjUy_aXwDpVxzi1ARf3jcPd7M.jpg?auto=webp&s=4ee9ded04b8633876fbde4d28c5b216f0eeac9a6"
thumb: "https://external-preview.redd.it/kSMssYYqIgWRJYepLyHjUy_aXwDpVxzi1ARf3jcPd7M.jpg?width=216&crop=smart&auto=webp&s=c2711169cbe1a440117eedb1c2b07375a59a3bd7"
visit: ""
---
I just finished shaving - did I miss any spots?
