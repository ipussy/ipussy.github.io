---
title:  "Would you lick it first or just dive right in?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/xLmbH4IZfThnntY-PP4TJWLs1mPXXsglWJOAFnTzGU4.jpg?auto=webp&s=88645a01f9611cb34aea7410c9aba5f826cf7be4"
thumb: "https://external-preview.redd.it/xLmbH4IZfThnntY-PP4TJWLs1mPXXsglWJOAFnTzGU4.jpg?width=960&crop=smart&auto=webp&s=a5a1f3fd0477408268cd2fd2692bc4bc3555c906"
visit: ""
---
Would you lick it first or just dive right in?
