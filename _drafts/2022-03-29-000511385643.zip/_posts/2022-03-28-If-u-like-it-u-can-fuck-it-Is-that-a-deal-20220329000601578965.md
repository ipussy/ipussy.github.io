---
title:  "If u like it, u can fuck it. Is that a deal?"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/uoagt0zan5q81.jpg?auto=webp&s=f28e55da74e53fa8a9b03ec4f03a90cb847bcbf2"
thumb: "https://preview.redd.it/uoagt0zan5q81.jpg?width=1080&crop=smart&auto=webp&s=a0c3228df877631e0deb3deff3b167b3ecc28fab"
visit: ""
---
If u like it, u can fuck it. Is that a deal?
