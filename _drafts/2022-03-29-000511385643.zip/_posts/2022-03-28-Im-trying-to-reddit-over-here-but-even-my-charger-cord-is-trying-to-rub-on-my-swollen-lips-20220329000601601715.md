---
title:  "I'm trying to reddit over here, but even my charger cord is trying to rub on my swollen lips"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/6zcb24i205q81.jpg?auto=webp&s=6cc5e52fa36859b601daeacd2b7fb1d168441222"
thumb: "https://preview.redd.it/6zcb24i205q81.jpg?width=1080&crop=smart&auto=webp&s=cd773cd8731e93128b8f4ed6a63d92f67548b80e"
visit: ""
---
I'm trying to reddit over here, but even my charger cord is trying to rub on my swollen lips
