---
title:  "Fresh shave with a little bush as a treat"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/cxeempnr5cq81.jpg?auto=webp&s=792c1d1900bcacb2c0574745a160b728f2998c8f"
thumb: "https://preview.redd.it/cxeempnr5cq81.jpg?width=1080&crop=smart&auto=webp&s=1665b3fe7215f416bc632e7acc8db392b19efb0b"
visit: ""
---
Fresh shave with a little bush as a treat
