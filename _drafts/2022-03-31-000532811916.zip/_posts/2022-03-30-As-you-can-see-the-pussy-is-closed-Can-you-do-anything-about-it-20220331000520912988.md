---
title:  "As you can see, the pussy is closed. Can you do anything about it?"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/uqAtotzph4C7QmmQWoUMQ6CieLuUeO7kdkqYeWQYv2g.jpg?auto=webp&s=a677e50abd4be0b4f76f907394e4ec2a3d05874c"
thumb: "https://external-preview.redd.it/uqAtotzph4C7QmmQWoUMQ6CieLuUeO7kdkqYeWQYv2g.jpg?width=1080&crop=smart&auto=webp&s=983635ab9057f79f44a2b20bc962b216ad0178d7"
visit: ""
---
As you can see, the pussy is closed. Can you do anything about it?
