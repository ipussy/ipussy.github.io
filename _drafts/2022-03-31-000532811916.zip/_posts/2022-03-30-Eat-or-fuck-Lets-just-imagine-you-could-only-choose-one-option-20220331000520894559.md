---
title:  "Eat or fuck? Let’s just imagine you could only choose one option…"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/sON-uH5Xn6MZKdmZYc_A0MPWUHjomNYYqZK3IJ9uA5s.jpg?auto=webp&s=f925cc34ed9e201d74fb166607982ba6ec696b99"
thumb: "https://external-preview.redd.it/sON-uH5Xn6MZKdmZYc_A0MPWUHjomNYYqZK3IJ9uA5s.jpg?width=216&crop=smart&auto=webp&s=d65dbd85eba12142a04b2aab4eb5c9828608b5fb"
visit: ""
---
Eat or fuck? Let’s just imagine you could only choose one option…
