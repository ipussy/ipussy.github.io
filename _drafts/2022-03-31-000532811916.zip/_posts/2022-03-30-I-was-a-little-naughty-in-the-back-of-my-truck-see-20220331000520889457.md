---
title:  "I was a little naughty in the back of my truck, see."
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/a0hGNPomFQU0vR7EnFDB0wBNvYHyKDw0WIgcqlc0V7Q.jpg?auto=webp&s=ed499ee5eae0a14b5773fd8d7e034e009956ab27"
thumb: "https://external-preview.redd.it/a0hGNPomFQU0vR7EnFDB0wBNvYHyKDw0WIgcqlc0V7Q.jpg?width=216&crop=smart&auto=webp&s=d8feb16e89d85882bc856721de43365807fab9f4"
visit: ""
---
I was a little naughty in the back of my truck, see.
