---
title:  "My ex hated oral, I love oral. Looking for someone who will share my tastes so we can reciprocate and 69"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/UIKl_BK-ksXu0jtE36eiccXfNNu21BsUaE9U1ppcaJ4.jpg?auto=webp&s=b999ceed5b7a8cb524986dfc273efe741871b21e"
thumb: "https://external-preview.redd.it/UIKl_BK-ksXu0jtE36eiccXfNNu21BsUaE9U1ppcaJ4.jpg?width=1080&crop=smart&auto=webp&s=37e7331846a866778f474e4b4963ebfce15cdf4f"
visit: ""
---
My ex hated oral, I love oral. Looking for someone who will share my tastes so we can reciprocate and 69
