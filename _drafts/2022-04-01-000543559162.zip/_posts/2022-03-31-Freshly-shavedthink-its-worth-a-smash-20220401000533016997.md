---
title:  "Freshly shaved…think it’s worth a smash? 😜"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/phhnnfnuwqq81.jpg?auto=webp&s=5b0c22343d853c894266790815490db79ed437b2"
thumb: "https://preview.redd.it/phhnnfnuwqq81.jpg?width=1080&crop=smart&auto=webp&s=6edda6601213e78138f7a9a6cb9e10354a63163d"
visit: ""
---
Freshly shaved…think it’s worth a smash? 😜
