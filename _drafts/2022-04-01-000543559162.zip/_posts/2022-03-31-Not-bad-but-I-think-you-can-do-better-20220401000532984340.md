---
title:  "Not bad but I think you can do better."
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/tn01rtglfpq81.jpg?auto=webp&s=0c7e668936101b11ecdbfcc61a7a36db93e5c59f"
thumb: "https://preview.redd.it/tn01rtglfpq81.jpg?width=1080&crop=smart&auto=webp&s=137cfefbf9ae00eb9d10ac39e0faf894853be13b"
visit: ""
---
Not bad but I think you can do better.
