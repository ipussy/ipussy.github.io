---
title:  "Waiting for a Texas sized lick this morning"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/UVxdpyTPkicBpnfP6LBeOCnOc195fS0b2_jEAbeB1fY.jpg?auto=webp&s=fca2ae89e10fa1161d4cb8cae54b6fcb8932af3a"
thumb: "https://external-preview.redd.it/UVxdpyTPkicBpnfP6LBeOCnOc195fS0b2_jEAbeB1fY.jpg?width=1080&crop=smart&auto=webp&s=773c48490670abe83015e2e09bb2ef12207718c3"
visit: ""
---
Waiting for a Texas sized lick this morning
