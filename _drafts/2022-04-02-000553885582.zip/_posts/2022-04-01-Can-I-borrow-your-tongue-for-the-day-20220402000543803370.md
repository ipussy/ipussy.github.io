---
title:  "Can I borrow your tongue for the day? ;)"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/6t3dee1fwwq81.jpg?auto=webp&s=c2b5989a7a6fdae951e19001ef92787056802adc"
thumb: "https://preview.redd.it/6t3dee1fwwq81.jpg?width=1080&crop=smart&auto=webp&s=df1cabd93aaaa2e036aa24ff7de4e17dd88bd740"
visit: ""
---
Can I borrow your tongue for the day? ;)
