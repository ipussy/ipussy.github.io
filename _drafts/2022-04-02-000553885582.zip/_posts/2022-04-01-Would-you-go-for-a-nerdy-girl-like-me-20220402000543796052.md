---
title:  "Would you go for a nerdy girl like me?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/ysrb2h84nxq81.jpg?auto=webp&s=8418bbb84a476632781d257f2d40b2bd1cf502d3"
thumb: "https://preview.redd.it/ysrb2h84nxq81.jpg?width=1080&crop=smart&auto=webp&s=21ba079d4ca6c0a26f90c569ad9cddb1a9cebadd"
visit: ""
---
Would you go for a nerdy girl like me?
