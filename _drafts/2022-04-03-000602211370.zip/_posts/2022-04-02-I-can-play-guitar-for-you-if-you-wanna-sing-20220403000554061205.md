---
title:  "I can play guitar for you if you wanna sing 🥵"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/9j2b71cS9noQTorEuGNE_f7_2x8Tx7GAfH3z7GxyhzQ.jpg?auto=webp&s=26b018c70d4aea4bd35dade6ac74c09865c588f3"
thumb: "https://external-preview.redd.it/9j2b71cS9noQTorEuGNE_f7_2x8Tx7GAfH3z7GxyhzQ.jpg?width=320&crop=smart&auto=webp&s=f1e073e83e8cfa8661d187dee4d70416c66bb3a3"
visit: ""
---
I can play guitar for you if you wanna sing 🥵
