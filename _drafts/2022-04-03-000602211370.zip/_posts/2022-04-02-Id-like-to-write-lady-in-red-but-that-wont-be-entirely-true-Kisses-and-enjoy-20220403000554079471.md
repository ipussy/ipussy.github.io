---
title:  "I'd like to write lady in red, but that won't be entirely true. Kisses and enjoy."
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/yj4QN83ra-t1ZRF1E2KKhF9Zct_QXJzDzZNY9l1A9hs.jpg?auto=webp&s=6607e23772d60787910378c4c52526a7ca1861c0"
thumb: "https://external-preview.redd.it/yj4QN83ra-t1ZRF1E2KKhF9Zct_QXJzDzZNY9l1A9hs.jpg?width=640&crop=smart&auto=webp&s=e240449c234e5dfd851a19a99949a106f8da6b9d"
visit: ""
---
I'd like to write lady in red, but that won't be entirely true. Kisses and enjoy.
