---
title:  "I’ve heard that you love vanilla macarons.. tell me baby if I’m wrong"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/w98ri2rq60r81.jpg?auto=webp&s=84aa8ad2acc045421d38308475d482ec189b9559"
thumb: "https://preview.redd.it/w98ri2rq60r81.jpg?width=640&crop=smart&auto=webp&s=7ac0cdbd86e6b631bd86ac7b6665ddd4ff8142d2"
visit: ""
---
I’ve heard that you love vanilla macarons.. tell me baby if I’m wrong
