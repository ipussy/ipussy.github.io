---
title:  "what are you sticking in first: your tongue or your dick :p ?"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/ppizi5vwy4r81.jpg?auto=webp&s=ab32988f39fdf5c24387ec36194e9a301353dc34"
thumb: "https://preview.redd.it/ppizi5vwy4r81.jpg?width=1080&crop=smart&auto=webp&s=eab5f7aa802c70b73ea6c93660b4aebe402da552"
visit: ""
---
what are you sticking in first: your tongue or your dick :p ?
