---
title:  "Freshly shaved and moist - is that your type?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/jff5s0m1lar81.jpg?auto=webp&s=8afc01d795f5f6bed6a74341507fb3c8aa6e9166"
thumb: "https://preview.redd.it/jff5s0m1lar81.jpg?width=640&crop=smart&auto=webp&s=1aedf30d0ee9dd87845c87a22e09dc3ef497803c"
visit: ""
---
Freshly shaved and moist - is that your type?
