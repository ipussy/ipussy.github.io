---
title:  "I guess that you would never go for a nerdy girl like me.."
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/ZLetP_N4JC75UHOCM5n_BsTFeQV6y0DQKrrO5gsi2CE.jpg?auto=webp&s=233c92af97da09b7ab42aa8bf1d1315d33f04011"
thumb: "https://external-preview.redd.it/ZLetP_N4JC75UHOCM5n_BsTFeQV6y0DQKrrO5gsi2CE.jpg?width=640&crop=smart&auto=webp&s=3e41e096e76146d8b0e72b4f1e96518a8b50fb3c"
visit: ""
---
I guess that you would never go for a nerdy girl like me..
