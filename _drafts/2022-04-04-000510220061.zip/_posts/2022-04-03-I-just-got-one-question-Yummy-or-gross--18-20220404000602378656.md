---
title:  "I just got one question…. Yummy or gross ? (18)"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/PwUSG4Zrh_MX4RCjB7Jkht7J5xsy4PcSDGkmD_7OD0U.jpg?auto=webp&s=b30b6fd1e3266e274b515ff417fb444f8f78cc12"
thumb: "https://external-preview.redd.it/PwUSG4Zrh_MX4RCjB7Jkht7J5xsy4PcSDGkmD_7OD0U.jpg?width=216&crop=smart&auto=webp&s=53664e79a8e03f0fa4276727676aefd0f1156842"
visit: ""
---
I just got one question…. Yummy or gross ? (18)
