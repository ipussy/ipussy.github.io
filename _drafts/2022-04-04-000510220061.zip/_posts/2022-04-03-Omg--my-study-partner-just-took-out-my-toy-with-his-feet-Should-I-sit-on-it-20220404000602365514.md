---
title:  "Omg , my study partner just took out my toy with his feet. Should I sit on it?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/sG-zmEhAWalia8ZUYMjc3pOWg-75q1XGGVc0s26XeFo.jpg?auto=webp&s=3e37e757396d775619c9abc8187088ac33122cc0"
thumb: "https://external-preview.redd.it/sG-zmEhAWalia8ZUYMjc3pOWg-75q1XGGVc0s26XeFo.jpg?width=216&crop=smart&auto=webp&s=245f87dae88a539b347889748299d38b5727afbf"
visit: ""
---
Omg , my study partner just took out my toy with his feet. Should I sit on it?
