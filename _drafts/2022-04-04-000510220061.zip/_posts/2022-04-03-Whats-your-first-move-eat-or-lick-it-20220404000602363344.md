---
title:  "What's your first move, eat or lick it?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/gW79WFdVOx_j-1yGcM7UBp1DUwe2JxrEIq-xFs0Ako8.jpg?auto=webp&s=8f4a8b6712a4e4f0fad082d30148572d4fa484d1"
thumb: "https://external-preview.redd.it/gW79WFdVOx_j-1yGcM7UBp1DUwe2JxrEIq-xFs0Ako8.jpg?width=1080&crop=smart&auto=webp&s=644a52e9fed7aff472130a84d1f6ca2713eb6798"
visit: ""
---
What's your first move, eat or lick it?
