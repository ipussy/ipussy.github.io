---
title:  "Can I borrow your tongue for a little?"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/hK8_tnrbYeqoT2u47mHEoBA_-4tB0FsCDh16ILdt4ho.jpg?auto=webp&s=ffcd76d13daa49c23d104dd8d381b6e7e2c3ca63"
thumb: "https://external-preview.redd.it/hK8_tnrbYeqoT2u47mHEoBA_-4tB0FsCDh16ILdt4ho.jpg?width=1080&crop=smart&auto=webp&s=bd54b3caf7b055867cbe8394e01c71a5035814d7"
visit: ""
---
Can I borrow your tongue for a little?
