---
title:  "I bet that not many guys would wife up a nerdy girl like me.."
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/tY2sEAJsd5FKc71MTrRd7YiRRK1ck6xY6Vb9rVO6Ddw.jpg?auto=webp&s=62e9438a5098df90d46acbed69962347b22b4ab8"
thumb: "https://external-preview.redd.it/tY2sEAJsd5FKc71MTrRd7YiRRK1ck6xY6Vb9rVO6Ddw.jpg?width=640&crop=smart&auto=webp&s=67a954612340e8f00f94e914611146169e9caf53"
visit: ""
---
I bet that not many guys would wife up a nerdy girl like me..
