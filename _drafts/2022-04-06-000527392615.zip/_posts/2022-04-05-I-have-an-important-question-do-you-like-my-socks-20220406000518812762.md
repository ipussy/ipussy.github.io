---
title:  "I have an important question, do you like my socks?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/1av4ly165pr81.jpg?auto=webp&s=11eeacaac0d51214186adae4f22f0b3b162fed69"
thumb: "https://preview.redd.it/1av4ly165pr81.jpg?width=960&crop=smart&auto=webp&s=a7c71132c2e7189eac69770d0d37210470d03e4c"
visit: ""
---
I have an important question, do you like my socks?
