---
title:  "Would you put your meat in my Mexican taco?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/rZ4cSGUdohybY70G0Ydp6wzwrPZk46VuKQKtARX2Gdc.jpg?auto=webp&s=0bfbe0ad7354376710d850c0e12ec9fdf624f65e"
thumb: "https://external-preview.redd.it/rZ4cSGUdohybY70G0Ydp6wzwrPZk46VuKQKtARX2Gdc.jpg?width=320&crop=smart&auto=webp&s=5fb2082218cb475486a1ed53ba508c619eb8c612"
visit: ""
---
Would you put your meat in my Mexican taco?
