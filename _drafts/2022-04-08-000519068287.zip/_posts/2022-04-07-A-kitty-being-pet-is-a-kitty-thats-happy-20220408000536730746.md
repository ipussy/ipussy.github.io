---
title:  "A kitty being pet is a kitty that’s happy!"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/EhpEcx4wy6Z3QnFI0I9BAXaDyON3HMSz7d6ibonbJVs.jpg?auto=webp&s=642afc37fc0c99b593d61fd9ab197739a55fb665"
thumb: "https://external-preview.redd.it/EhpEcx4wy6Z3QnFI0I9BAXaDyON3HMSz7d6ibonbJVs.jpg?width=640&crop=smart&auto=webp&s=5482d69952383d2b473c4a928bdecc824480d126"
visit: ""
---
A kitty being pet is a kitty that’s happy!
