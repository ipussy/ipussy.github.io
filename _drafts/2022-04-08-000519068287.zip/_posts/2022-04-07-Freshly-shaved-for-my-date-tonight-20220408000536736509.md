---
title:  "Freshly shaved for my date tonight"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/hn185r7bq4s81.jpg?auto=webp&s=6a6d743dbc8bb08a4a89d57353ce6aea5ad31283"
thumb: "https://preview.redd.it/hn185r7bq4s81.jpg?width=1080&crop=smart&auto=webp&s=1c78cd8f3104aa7ab104e26c436d3434e3a542af"
visit: ""
---
Freshly shaved for my date tonight
