---
title:  "Freshly shaved and moist - is that your type? hehe"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/1xlakjtq2as81.jpg?auto=webp&s=aa7c169ea2ce68401fed2fb54ce9e0e3c6f3f620"
thumb: "https://preview.redd.it/1xlakjtq2as81.jpg?width=1080&crop=smart&auto=webp&s=b265c0cffcfdcf5aae2be14589ad4344f582e127"
visit: ""
---
Freshly shaved and moist - is that your type? hehe
