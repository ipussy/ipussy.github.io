---
title:  "Taking a quick break from the grind"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/RPSsx5mW9DeXzdFL-iVjA0YHxdDOyUZMKFlIedl4cAs.jpg?auto=webp&s=d0c64d9cede01c91d5c73296148dee37a3484fff"
thumb: "https://external-preview.redd.it/RPSsx5mW9DeXzdFL-iVjA0YHxdDOyUZMKFlIedl4cAs.jpg?width=960&crop=smart&auto=webp&s=80c2af57575ec2b8f07b428b8ca7fef21112e4d7"
visit: ""
---
Taking a quick break from the grind
