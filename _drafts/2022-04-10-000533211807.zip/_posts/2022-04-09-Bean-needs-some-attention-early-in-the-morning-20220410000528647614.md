---
title:  "Bean needs some attention early in the morning"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/LgQvjB_RKJ8wGSq7Of3cQZU5mthNp7r6v-qIp0PAIg0.jpg?auto=webp&s=4f8f8e30c9dc2e194063b34c34b7cd32ad2cad03"
thumb: "https://external-preview.redd.it/LgQvjB_RKJ8wGSq7Of3cQZU5mthNp7r6v-qIp0PAIg0.jpg?width=640&crop=smart&auto=webp&s=c5f2ada900a48292779c64144b6f699c2ad2b530"
visit: ""
---
Bean needs some attention early in the morning
