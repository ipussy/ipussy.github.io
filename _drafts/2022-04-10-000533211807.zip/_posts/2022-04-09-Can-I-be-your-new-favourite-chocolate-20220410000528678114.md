---
title:  "Can I be your new favourite chocolate?"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/5baU8xivWzd2aFIC9MUd50POSv6A69l-uZzoWy2i3wY.jpg?auto=webp&s=b958b26aedcf1a8d33880aaf906897577a549cfd"
thumb: "https://external-preview.redd.it/5baU8xivWzd2aFIC9MUd50POSv6A69l-uZzoWy2i3wY.jpg?width=640&crop=smart&auto=webp&s=499e9a42bcd4b9a5846d3747c8244422da43cb40"
visit: ""
---
Can I be your new favourite chocolate?
