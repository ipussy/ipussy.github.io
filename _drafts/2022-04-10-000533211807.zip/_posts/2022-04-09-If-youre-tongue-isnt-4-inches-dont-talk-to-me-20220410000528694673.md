---
title:  "If you’re tongue isn’t 4 inches don’t talk to me 😂"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/oxxp0tctjis81.jpg?auto=webp&s=2b48b574acd8cfc303332f974a406b7356afa3a8"
thumb: "https://preview.redd.it/oxxp0tctjis81.jpg?width=1080&crop=smart&auto=webp&s=122d2cb509628bda16c76deaa158b5313ae912f8"
visit: ""
---
If you’re tongue isn’t 4 inches don’t talk to me 😂
