---
title:  "Where can I sit, on the face or on the dick? [OC]"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/vpZpc41_wW4vQ-n8tnoF5sDiORLh8VZkosEl0JFqWhc.jpg?auto=webp&s=9281aea740cd3a8691fa699251e5f560cb468c97"
thumb: "https://external-preview.redd.it/vpZpc41_wW4vQ-n8tnoF5sDiORLh8VZkosEl0JFqWhc.jpg?width=216&crop=smart&auto=webp&s=fa3ba18c325642507619c54edb6f71bd9d5a15d2"
visit: ""
---
Where can I sit, on the face or on the dick? [OC]
