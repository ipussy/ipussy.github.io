---
title:  "Would you dive in with your cock or tongue first?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/Fzs0zKQdPNGLEnZpxJBNShoueNOv6a6NRMwckQG7MbM.jpg?auto=webp&s=a8200f5cd9ebaef2688f15ea1ef797d07e6c7a41"
thumb: "https://external-preview.redd.it/Fzs0zKQdPNGLEnZpxJBNShoueNOv6a6NRMwckQG7MbM.jpg?width=640&crop=smart&auto=webp&s=f2f7715f2b90822e97a94372be43e21d8005276b"
visit: ""
---
Would you dive in with your cock or tongue first?
