---
title:  "do you wanna lick it or fuck it first?"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/gzPZp4knmuaJEtA2bf_XOZvyZ7RChKIb_jPdpBv8RBQ.jpg?auto=webp&s=2c148802a3c931fb1165f0e8f45c01aeed2a3583"
thumb: "https://external-preview.redd.it/gzPZp4knmuaJEtA2bf_XOZvyZ7RChKIb_jPdpBv8RBQ.jpg?width=216&crop=smart&auto=webp&s=e333b10c6e95f8fedc0bf5e69980b0681f94d5a4"
visit: ""
---
do you wanna lick it or fuck it first?
