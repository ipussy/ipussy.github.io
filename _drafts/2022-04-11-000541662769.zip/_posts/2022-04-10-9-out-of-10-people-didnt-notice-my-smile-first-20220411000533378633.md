---
title:  "9 out of 10 people didn’t notice my smile first"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/fjlf4kxdzps81.jpg?auto=webp&s=68d89eb42b8d0c6c6bc0dc954750c53824250ba2"
thumb: "https://preview.redd.it/fjlf4kxdzps81.jpg?width=1080&crop=smart&auto=webp&s=2aa6cb007fed8b9c755711999c07a2e6992024f3"
visit: ""
---
9 out of 10 people didn’t notice my smile first
