---
title:  "Freshly shaved and she’s lookin so pretty"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/g2owkff6axs81.jpg?auto=webp&s=b6cf2bef3f03ba463079a17f05b47fc9eb3260e9"
thumb: "https://preview.redd.it/g2owkff6axs81.jpg?width=1080&crop=smart&auto=webp&s=94e3086c7f2e80143702461e84238d59ded5007e"
visit: ""
---
Freshly shaved and she’s lookin so pretty
