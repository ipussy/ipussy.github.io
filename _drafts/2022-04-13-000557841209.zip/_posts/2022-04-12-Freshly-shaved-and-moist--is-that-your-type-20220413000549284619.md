---
title:  "Freshly shaved and moist - is that your type?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/4u4n1hisq2t81.jpg?auto=webp&s=45c6520aaa8fe0b0aac1fe4ae93ecb37e306a3ea"
thumb: "https://preview.redd.it/4u4n1hisq2t81.jpg?width=1080&crop=smart&auto=webp&s=53c21850672fc017c052fdd027a4567148dc6c3e"
visit: ""
---
Freshly shaved and moist - is that your type?
