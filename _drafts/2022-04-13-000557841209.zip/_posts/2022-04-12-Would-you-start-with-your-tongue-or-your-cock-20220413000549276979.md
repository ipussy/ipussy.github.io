---
title:  "Would you start with your tongue or your cock?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/xPeCYGizeKnN4pDt43xnOeAmrbBhowsVioYu68Wp8mw.jpg?auto=webp&s=dd4cf22807cd57deac6cdfe2ce60e4f6da2971c8"
thumb: "https://external-preview.redd.it/xPeCYGizeKnN4pDt43xnOeAmrbBhowsVioYu68Wp8mw.jpg?width=216&crop=smart&auto=webp&s=5c1c65e74c97ec2151c50030894733eb3a2d82ca"
visit: ""
---
Would you start with your tongue or your cock?
