---
title:  "For research purposes, the same pic but without a shirt 😝"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/9mafdp5te5t81.jpg?auto=webp&s=d5c065f034031af40f3ba297257e236d6484ecfd"
thumb: "https://preview.redd.it/9mafdp5te5t81.jpg?width=1080&crop=smart&auto=webp&s=eeb9e2f1b84ee47f4edb580b1fb75c9e40cf060d"
visit: ""
---
For research purposes, the same pic but without a shirt 😝
