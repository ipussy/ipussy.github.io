---
title:  "My pussy after taking my first huge bad dragon dildo!! I got stretched out so much I’m so surprised I managed to take it all. My pussy used to be so right now She’s so loose I stretched her out in literally 3 weeks. She can take any toys now"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/m90e8f20wit81.jpg?auto=webp&s=6c3eff0737e89ea051768f9fa733900ddc4c3f74"
thumb: "https://preview.redd.it/m90e8f20wit81.jpg?width=640&crop=smart&auto=webp&s=42e3d9d9466c76fc86ef8247580e2671ba0a8b72"
visit: ""
---
My pussy after taking my first huge bad dragon dildo!! I got stretched out so much I’m so surprised I managed to take it all. My pussy used to be so right now She’s so loose I stretched her out in literally 3 weeks. She can take any toys now
