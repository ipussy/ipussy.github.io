---
title:  "Would you eat out your boss to get ahead at work? (Mid-thirties Exec)"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/pw_VofuMst2td8uMzy9KvbFsla4z2ZEjqHE6mNfj-xM.jpg?auto=webp&s=633f9de655ddb6ef5dc72a3d851c5c3af93518a7"
thumb: "https://external-preview.redd.it/pw_VofuMst2td8uMzy9KvbFsla4z2ZEjqHE6mNfj-xM.jpg?width=320&crop=smart&auto=webp&s=2f7169a01570aa330b20a518f3678f271ac88c83"
visit: ""
---
Would you eat out your boss to get ahead at work? (Mid-thirties Exec)
