---
title:  "Can you smash it with your tongue for me?"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/7Ld9K22NLWIRR6xL2TDcEYHZHP3X2ND3UP7NaA9ERiI.jpg?auto=webp&s=66232aa045f66df66a9b3088dfe3c9b953ca19e7"
thumb: "https://external-preview.redd.it/7Ld9K22NLWIRR6xL2TDcEYHZHP3X2ND3UP7NaA9ERiI.jpg?width=1080&crop=smart&auto=webp&s=ee5f584c7d01e3bfeffa43ee059468111d0cdf05"
visit: ""
---
Can you smash it with your tongue for me?
