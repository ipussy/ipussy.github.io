---
title:  "Might regret this, but freshly waxed teen pussy… smash or pass?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/nfhcaxgoyot81.jpg?auto=webp&s=e83f637f3c1f4b804001ff08166739cb7e893931"
thumb: "https://preview.redd.it/nfhcaxgoyot81.jpg?width=640&crop=smart&auto=webp&s=aaa502d0fe3a22899604e4e894371b86015ac30e"
visit: ""
---
Might regret this, but freshly waxed teen pussy… smash or pass?
