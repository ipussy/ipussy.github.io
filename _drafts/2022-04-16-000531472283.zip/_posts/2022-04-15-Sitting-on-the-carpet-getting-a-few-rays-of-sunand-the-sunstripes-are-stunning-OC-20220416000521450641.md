---
title:  "Sitting on the carpet getting a few rays of sun-and the sunstripes are stunning [OC]"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/D1BlhY7y4XWBAzGaljYFx0_e2vo4wIjArqOUvW33GDQ.jpg?auto=webp&s=0081081787ebd6efa7b327ee89a6e1eb66a55335"
thumb: "https://external-preview.redd.it/D1BlhY7y4XWBAzGaljYFx0_e2vo4wIjArqOUvW33GDQ.jpg?width=1080&crop=smart&auto=webp&s=2cbf1b5895e5b0af54e6f5d00a1526a0e187cea5"
visit: ""
---
Sitting on the carpet getting a few rays of sun-and the sunstripes are stunning [OC]
