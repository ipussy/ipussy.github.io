---
title:  "They call it a headboard but I use it for support a different way"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/dGYR-TNO4rHODlUryeT4zeD6niFvI5QrZ-0KXX5O6Tg.jpg?auto=webp&s=bb964323818baf64c2d941d9f4883397408ed0b5"
thumb: "https://external-preview.redd.it/dGYR-TNO4rHODlUryeT4zeD6niFvI5QrZ-0KXX5O6Tg.jpg?width=1080&crop=smart&auto=webp&s=ff664d4c4b47e580a58381cea8ff23eaeb0313fd"
visit: ""
---
They call it a headboard but I use it for support a different way
