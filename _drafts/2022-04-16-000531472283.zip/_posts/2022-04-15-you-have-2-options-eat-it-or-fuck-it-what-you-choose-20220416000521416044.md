---
title:  "you have 2 options.. eat it or fuck it.. what you choose?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/ru0o340nflt81.jpg?auto=webp&s=e5b470de46292036be1e4091092881ee675ab172"
thumb: "https://preview.redd.it/ru0o340nflt81.jpg?width=1080&crop=smart&auto=webp&s=7e51bccabd6eaa0be1c3e7645b9e6a8976da8824"
visit: ""
---
you have 2 options.. eat it or fuck it.. what you choose?
