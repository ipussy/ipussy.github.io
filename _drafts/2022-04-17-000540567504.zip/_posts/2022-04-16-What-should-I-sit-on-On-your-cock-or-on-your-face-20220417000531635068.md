---
title:  "What should I sit on? On your cock or on your face?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/3j6qLbJDmzRpD1AGaj5fPUYDWvqFDgmaT6_q78XGl2I.jpg?auto=webp&s=fa48609927cbb3a7cb787288b8892ef2a151d37b"
thumb: "https://external-preview.redd.it/3j6qLbJDmzRpD1AGaj5fPUYDWvqFDgmaT6_q78XGl2I.jpg?width=1080&crop=smart&auto=webp&s=ec6a3e60d50844ca8b6bc5b5c1df2fe6f7f4dd17"
visit: ""
---
What should I sit on? On your cock or on your face?
