---
title:  "I am connected and so helpless, do what you want with me"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/mGXI6dRjBHKqKmhIkckUv7AXseBnd-YYFhFDJYKpXPY.jpg?auto=webp&s=2b08625c0f8f861e32d16c3ad99bc86a75474c51"
thumb: "https://external-preview.redd.it/mGXI6dRjBHKqKmhIkckUv7AXseBnd-YYFhFDJYKpXPY.jpg?width=1080&crop=smart&auto=webp&s=c9e065ef72632fa93f36e6cf3ef68dba916d1154"
visit: ""
---
I am connected and so helpless, do what you want with me
