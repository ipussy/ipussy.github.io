---
title:  "Took this pic for my bf while he was at work... he didn't get much work done 😅"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/4DhzqHpWI_BKiDuDRoc9hZotn1W-f3q4auWPITPzhWc.jpg?auto=webp&s=0acf640864c5693793647397ed0dfe4e361d298a"
thumb: "https://external-preview.redd.it/4DhzqHpWI_BKiDuDRoc9hZotn1W-f3q4auWPITPzhWc.jpg?width=1080&crop=smart&auto=webp&s=17b68548782d66e4f1350fb96ec4b68cbf8ccd10"
visit: ""
---
Took this pic for my bf while he was at work... he didn't get much work done 😅
