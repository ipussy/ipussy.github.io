---
title:  "Do you mind eating breakfast on the stairs?"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/ai06n5v7abu81.jpg?auto=webp&s=c5dbc10009926fe8c31f6aadec63a4c5eb675d46"
thumb: "https://preview.redd.it/ai06n5v7abu81.jpg?width=1080&crop=smart&auto=webp&s=e8db14f025299c26cb759071201591138b63de46"
visit: ""
---
Do you mind eating breakfast on the stairs?
