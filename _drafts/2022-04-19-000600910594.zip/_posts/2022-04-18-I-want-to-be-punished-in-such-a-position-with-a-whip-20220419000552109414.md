---
title:  "I want to be punished in such a position with a whip"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/JaqQq-zsFDH_a62JkUD4QHM8Rb6z88He3xGx0uwK-14.jpg?auto=webp&s=28041f4c0c6fa8aa0b374571b6b036b95c9fd0bb"
thumb: "https://external-preview.redd.it/JaqQq-zsFDH_a62JkUD4QHM8Rb6z88He3xGx0uwK-14.jpg?width=1080&crop=smart&auto=webp&s=2deab57ad85b66a922edeb9e8079ffe7e5318620"
visit: ""
---
I want to be punished in such a position with a whip
