---
title:  "Is it wrong I like to be degraded? A guy called me a dumb, sexy whore yesterday and I got horny 🥺 even though I know I’m a smart, sexy whore"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/quesjg8t3bu81.jpg?auto=webp&s=ac4e6ee4b3e6f69dde11a395381ca7508b2db215"
thumb: "https://preview.redd.it/quesjg8t3bu81.jpg?width=640&crop=smart&auto=webp&s=3670115e6bdc35c86bf85d4c11ad115a983446f1"
visit: ""
---
Is it wrong I like to be degraded? A guy called me a dumb, sexy whore yesterday and I got horny 🥺 even though I know I’m a smart, sexy whore
