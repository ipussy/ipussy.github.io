---
title:  "What would you do if I sent you this straight after our first date? 🙊"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/Aq5aAXeM7wpYV0DQxlXHLNNXLieb24VlFDyU_BdrgMQ.jpg?auto=webp&s=a1c585ba414403790edd75cc619ffdd660d13e44"
thumb: "https://external-preview.redd.it/Aq5aAXeM7wpYV0DQxlXHLNNXLieb24VlFDyU_BdrgMQ.jpg?width=640&crop=smart&auto=webp&s=ad82a99fdbfacb5d28dc5e8b152dd667f64a5721"
visit: ""
---
What would you do if I sent you this straight after our first date? 🙊
