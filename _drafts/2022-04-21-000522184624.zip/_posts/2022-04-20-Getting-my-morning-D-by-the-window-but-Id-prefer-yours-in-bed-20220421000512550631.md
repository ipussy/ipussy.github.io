---
title:  "Getting my morning D by the window, but I'd prefer yours in bed!"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/o7w1924tzou81.jpg?auto=webp&s=b834adbe836e6a621eaf114af253a9dfbde1c138"
thumb: "https://preview.redd.it/o7w1924tzou81.jpg?width=1080&crop=smart&auto=webp&s=06214deeda366729e1f9a0710922ed645fffefc5"
visit: ""
---
Getting my morning D by the window, but I'd prefer yours in bed!
