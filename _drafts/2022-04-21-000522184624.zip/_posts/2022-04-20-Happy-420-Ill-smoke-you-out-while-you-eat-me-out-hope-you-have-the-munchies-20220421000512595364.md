---
title:  "Happy 420! I’ll smoke you out while you eat me out, hope you have the munchies"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/C3FZ2Zpk5nIKRpnMfutZ9jVJHbj1Mlf7lItEn-PiCDU.jpg?auto=webp&s=68365e4ed1d8fb6fb03729da22974660a962a391"
thumb: "https://external-preview.redd.it/C3FZ2Zpk5nIKRpnMfutZ9jVJHbj1Mlf7lItEn-PiCDU.jpg?width=320&crop=smart&auto=webp&s=e9311b1bbce67f2c1e9c13ab5a2a7213506b5275"
visit: ""
---
Happy 420! I’ll smoke you out while you eat me out, hope you have the munchies
