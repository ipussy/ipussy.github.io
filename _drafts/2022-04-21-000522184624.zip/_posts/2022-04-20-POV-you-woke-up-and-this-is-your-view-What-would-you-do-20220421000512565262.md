---
title:  "POV: you woke up and this is your view. What would you do?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/xyHM5QPMJrdzahlgLIngUTq2hG1y3bq2CV-3Zfxt39I.jpg?auto=webp&s=f4ef8cfa86cc8f0ae8ed59535d61e7665b7fc0b2"
thumb: "https://external-preview.redd.it/xyHM5QPMJrdzahlgLIngUTq2hG1y3bq2CV-3Zfxt39I.jpg?width=320&crop=smart&auto=webp&s=854dd0d7edb826c4afe086be937a9f873646483d"
visit: ""
---
POV: you woke up and this is your view. What would you do?
