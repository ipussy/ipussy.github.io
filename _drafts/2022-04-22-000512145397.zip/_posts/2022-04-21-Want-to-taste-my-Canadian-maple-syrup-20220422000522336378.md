---
title:  "Want to taste my Canadian maple syrup…"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/KaoYVeC6othl_tlP4GEJ_Pc358WycS_1IDhixxBEQA0.jpg?auto=webp&s=2146d1f19295336e77efb51c5c555e64c1cfeba2"
thumb: "https://external-preview.redd.it/KaoYVeC6othl_tlP4GEJ_Pc358WycS_1IDhixxBEQA0.jpg?width=216&crop=smart&auto=webp&s=dfabaf1c249f2210b2cec4e7c2597bf163b33e4a"
visit: ""
---
Want to taste my Canadian maple syrup…
