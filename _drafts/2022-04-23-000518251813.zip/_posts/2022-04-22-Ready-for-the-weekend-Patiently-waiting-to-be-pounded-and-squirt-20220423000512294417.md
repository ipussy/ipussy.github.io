---
title:  "Ready for the weekend. Patiently waiting to be pounded and squirt 🤤"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/f89imanis3v81.jpg?auto=webp&s=03129d22831c177703b2b62a7e664e05a1ecff04"
thumb: "https://preview.redd.it/f89imanis3v81.jpg?width=1080&crop=smart&auto=webp&s=4b1b2a108f0c5a18349951f9996fb935686b5897"
visit: ""
---
Ready for the weekend. Patiently waiting to be pounded and squirt 🤤
