---
title:  "First you have to lick it and after to slide in, deal? ;)"
metadate: "hide"
categories: [ Rear Pussy ]
image: "https://external-preview.redd.it/ePXT_YtUJIBy-ze8zeyhNNWZAg7Iu-ruX67hE6FaR08.jpg?auto=webp&s=c7b478f2891994ee199c38eb1826884dd2e9f3fd"
thumb: "https://external-preview.redd.it/ePXT_YtUJIBy-ze8zeyhNNWZAg7Iu-ruX67hE6FaR08.jpg?width=640&crop=smart&auto=webp&s=1292bc169ef9fc3b060e9d479a298749a5c4280f"
visit: ""
---
First you have to lick it and after to slide in, deal? ;)
