---
title:  "Want to taste my Canadian maple syrup…"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/QxwsZVXuqqxrKwWSeaqyP2vd4l5j3l7rfVijTMn-U2k.jpg?auto=webp&s=16eccab2a8a650eba5934545c7dac3b9b1441c01"
thumb: "https://external-preview.redd.it/QxwsZVXuqqxrKwWSeaqyP2vd4l5j3l7rfVijTMn-U2k.jpg?width=216&crop=smart&auto=webp&s=23dedd070d34643b381f6b6455647bba162da243"
visit: ""
---
Want to taste my Canadian maple syrup…
