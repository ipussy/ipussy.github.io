---
title:  "Are you going to eat it first or shove it right in?"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/qfgvwyeiqov81.jpg?auto=webp&s=a19dd55a9db76fb380f4f8424b30351217c79a77"
thumb: "https://preview.redd.it/qfgvwyeiqov81.jpg?width=1080&crop=smart&auto=webp&s=899426bca665f6da66f2ac4ae00f15ac5ceed1d0"
visit: ""
---
Are you going to eat it first or shove it right in?
