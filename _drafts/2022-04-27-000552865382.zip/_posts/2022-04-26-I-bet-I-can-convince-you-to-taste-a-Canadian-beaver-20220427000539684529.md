---
title:  "I bet I can convince you to taste a Canadian beaver…"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/tGm_xa6dj_F2fNm7IJIktcM52eRylPKQ0pvLSlVKkGk.jpg?auto=webp&s=31b06ff1da34515e573b8ea2650afc469372b6ae"
thumb: "https://external-preview.redd.it/tGm_xa6dj_F2fNm7IJIktcM52eRylPKQ0pvLSlVKkGk.jpg?width=216&crop=smart&auto=webp&s=0920f9d8c018426feb6a1761d2cc5255e77131df"
visit: ""
---
I bet I can convince you to taste a Canadian beaver…
