---
title:  "Decided to skip work today and kids are in school…Would you come play with me?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/i2og9wnl82w81.jpg?auto=webp&s=6c4cc6e9ff6d57dc27d95fa02dc704abcd25290c"
thumb: "https://preview.redd.it/i2og9wnl82w81.jpg?width=1080&crop=smart&auto=webp&s=5f845dbb483e2503e6750ab9f5d137c390a804ae"
visit: ""
---
Decided to skip work today and kids are in school…Would you come play with me?
