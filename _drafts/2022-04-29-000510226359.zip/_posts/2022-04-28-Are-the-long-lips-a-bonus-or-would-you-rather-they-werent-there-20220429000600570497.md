---
title:  "Are the long lips a bonus or would you rather they weren’t there?"
metadate: "hide"
categories: [ Rear Pussy ]
image: "https://external-preview.redd.it/ybROgqvY-LBoqQ9GudYb7TRjpvYg2glWfRgRTBtm0Vg.jpg?auto=webp&s=e5023a580db0da05b600e59a30f9e6321f329996"
thumb: "https://external-preview.redd.it/ybROgqvY-LBoqQ9GudYb7TRjpvYg2glWfRgRTBtm0Vg.jpg?width=320&crop=smart&auto=webp&s=f0130705dd531f92f5887928fd6271d9e53cdc0a"
visit: ""
---
Are the long lips a bonus or would you rather they weren’t there?
