---
title:  "Freshly shaved and moist - is that your type?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/jsmwm7k1r8w81.jpg?auto=webp&s=413abd98799de5c39f811f0899f5b0cdc03514c4"
thumb: "https://preview.redd.it/jsmwm7k1r8w81.jpg?width=1080&crop=smart&auto=webp&s=deaa126765d7d8d83830de35662bd112b0ec79d8"
visit: ""
---
Freshly shaved and moist - is that your type?
