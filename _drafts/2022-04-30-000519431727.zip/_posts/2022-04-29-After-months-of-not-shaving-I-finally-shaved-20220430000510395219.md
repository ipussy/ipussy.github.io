---
title:  "After months of not shaving I finally shaved"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/xx03bi4cshw81.gif?format=png8&s=ab71a4c8850772ff6764b89999716f649ac91379"
thumb: "https://preview.redd.it/xx03bi4cshw81.gif?width=320&crop=smart&format=png8&s=0275ffb95da8c9668bb941e58ab73b5326590a81"
visit: ""
---
After months of not shaving I finally shaved
