---
title:  "Are you an ass or tits guy? Because I think I have both but my ass is a thing 🙈"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/cXqi-Qs-5PjQNpH2wCet3TkFDoaSNu6ogDDGRHgWpE4.jpg?auto=webp&s=b957d7c677f1f9b7386d017b7c61ed27cb2bb55a"
thumb: "https://external-preview.redd.it/cXqi-Qs-5PjQNpH2wCet3TkFDoaSNu6ogDDGRHgWpE4.jpg?width=216&crop=smart&auto=webp&s=6140a9bc7bb41d911cbac19bcb452e1dae6aaca8"
visit: ""
---
Are you an ass or tits guy? Because I think I have both but my ass is a thing 🙈
