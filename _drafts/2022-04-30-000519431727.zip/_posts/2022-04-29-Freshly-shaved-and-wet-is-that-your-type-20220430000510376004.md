---
title:  "Freshly shaved and wet, is that your type?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/nz8khhf72fw81.jpg?auto=webp&s=97e6a7f1fbe7da8a60ae75660ed08ab962252a13"
thumb: "https://preview.redd.it/nz8khhf72fw81.jpg?width=1080&crop=smart&auto=webp&s=d367c76472e3d6da7c0d561579964c675cd9cdf7"
visit: ""
---
Freshly shaved and wet, is that your type?
