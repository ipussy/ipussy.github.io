---
title:  "you have 2 options.. eat it or fuck it.. what you choose?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/lh4s6jw8okw81.jpg?auto=webp&s=b656a43eb3865f3d8d2c1ad42786fdb76c71d93d"
thumb: "https://preview.redd.it/lh4s6jw8okw81.jpg?width=1080&crop=smart&auto=webp&s=1cfac98ca76eab7bdc86abcdbc6dafe95bd82c31"
visit: ""
---
you have 2 options.. eat it or fuck it.. what you choose?
