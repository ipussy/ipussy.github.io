---
title:  "Always take two, it is better for conversation, if there ends up being any, you don't have to be involved."
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/o7zi3fsabvw81.jpg?auto=webp&s=604fa5918fd9014ee0a1665d3d9cf769a8ced5d6"
thumb: "https://preview.redd.it/o7zi3fsabvw81.jpg?width=1080&crop=smart&auto=webp&s=e8e0b43213e91fda97f11e02080e5b3e9a0d6cf9"
visit: ""
---
Always take two, it is better for conversation, if there ends up being any, you don't have to be involved.
