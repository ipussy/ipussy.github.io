---
title:  "Bean was waiting to be treated to lunch"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/rmOngbheAB4VjFJO68D-A1BG37rZbBm6_8WpAS-RgzY.jpg?auto=webp&s=70a4c68470dc0aaa012a86d4b6fff3e27755e668"
thumb: "https://external-preview.redd.it/rmOngbheAB4VjFJO68D-A1BG37rZbBm6_8WpAS-RgzY.jpg?width=1080&crop=smart&auto=webp&s=2e77064b9cb336f7705501ca0838419dd4055f7a"
visit: ""
---
Bean was waiting to be treated to lunch
