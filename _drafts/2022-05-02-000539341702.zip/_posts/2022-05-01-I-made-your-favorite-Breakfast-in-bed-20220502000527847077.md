---
title:  "I made your favorite…. Breakfast in bed"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/g2auzwlybvw81.jpg?auto=webp&s=4023b549b64cd68519c28cd2fdd775d94eb1a8d8"
thumb: "https://preview.redd.it/g2auzwlybvw81.jpg?width=1080&crop=smart&auto=webp&s=dbedd79783f85deef3676d1f4fe9df1ecfe46e09"
visit: ""
---
I made your favorite…. Breakfast in bed
