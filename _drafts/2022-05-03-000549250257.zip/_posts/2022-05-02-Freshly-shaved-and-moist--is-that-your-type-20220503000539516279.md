---
title:  "Freshly shaved and moist - is that your type?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/ll2hsrbgf1x81.jpg?auto=webp&s=376332a9ff874c2c46a7b10510a32440a7accf74"
thumb: "https://preview.redd.it/ll2hsrbgf1x81.jpg?width=640&crop=smart&auto=webp&s=3e077d8538d903866c36b0e327c9df305794b44f"
visit: ""
---
Freshly shaved and moist - is that your type?
