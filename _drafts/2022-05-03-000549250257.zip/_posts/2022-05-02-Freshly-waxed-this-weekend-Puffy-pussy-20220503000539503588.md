---
title:  "Freshly waxed this weekend. Puffy pussy"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/aoGDZKfUCtzv7sd1gUdVc4VhbtmMdljAP64vl9UUhao.jpg?auto=webp&s=826cf9f6e83e96d441c4009840f67defee820d3b"
thumb: "https://external-preview.redd.it/aoGDZKfUCtzv7sd1gUdVc4VhbtmMdljAP64vl9UUhao.jpg?width=960&crop=smart&auto=webp&s=df3b915e3e785be40346c3072efe703e077ebed5"
visit: ""
---
Freshly waxed this weekend. Puffy pussy
