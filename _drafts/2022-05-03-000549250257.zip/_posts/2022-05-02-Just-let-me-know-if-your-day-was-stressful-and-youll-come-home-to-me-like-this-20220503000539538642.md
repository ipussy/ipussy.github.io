---
title:  "Just let me know if your day was stressful and you’ll come home to me like this!"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/KkNT5wA0aJ8tV4upvVZBWrIrCwLFLFwmCWSPBTvpx_w.jpg?auto=webp&s=d349222de3935c077cfaf3f78929098ae89ec3cd"
thumb: "https://external-preview.redd.it/KkNT5wA0aJ8tV4upvVZBWrIrCwLFLFwmCWSPBTvpx_w.jpg?width=216&crop=smart&auto=webp&s=b35869ff8cfcf741bae53bf0ef31157c8b274fbb"
visit: ""
---
Just let me know if your day was stressful and you’ll come home to me like this!
