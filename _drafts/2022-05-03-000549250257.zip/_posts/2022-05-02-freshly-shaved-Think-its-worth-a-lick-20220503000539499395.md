---
title:  "freshly shaved. Think it’s worth a lick?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/jzQzyKWtor1YcpieWr_kWCV6RTs2IEHy4PyhWTAXAv4.jpg?auto=webp&s=137230272331c6d8a4fa6921db1be6b35c5a40fd"
thumb: "https://external-preview.redd.it/jzQzyKWtor1YcpieWr_kWCV6RTs2IEHy4PyhWTAXAv4.jpg?width=1080&crop=smart&auto=webp&s=92e0f3b83451acb6b36913cad214e34251460724"
visit: ""
---
freshly shaved. Think it’s worth a lick?
