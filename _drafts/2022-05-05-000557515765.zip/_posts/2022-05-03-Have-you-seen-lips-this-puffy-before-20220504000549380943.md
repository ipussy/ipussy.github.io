---
title:  "Have you seen lips this puffy before?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/CQvz-r527QFffR98JQt9sqMKF_0rmt3XxzAl1_nQd40.jpg?auto=webp&s=d8bb4f46f8e0c1bd68a5abfd84d1c77310c81e0d"
thumb: "https://external-preview.redd.it/CQvz-r527QFffR98JQt9sqMKF_0rmt3XxzAl1_nQd40.jpg?width=640&crop=smart&auto=webp&s=3dc6f73855f4ed576bb211ef567af842426b8d31"
visit: ""
---
Have you seen lips this puffy before?
