---
title:  "Stepbro asked what’s for dinner. I replied with this"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/cgIVzDss1SceXsnbySQlsjvF2Jj4v-abPVxJS9CPRIc.jpg?auto=webp&s=b3ce80ddc2c5bab884e3541a30158445f8f1ff7d"
thumb: "https://external-preview.redd.it/cgIVzDss1SceXsnbySQlsjvF2Jj4v-abPVxJS9CPRIc.jpg?width=216&crop=smart&auto=webp&s=9c150a983a00d8acf1687d46c66195f27435b2eb"
visit: ""
---
Stepbro asked what’s for dinner. I replied with this
