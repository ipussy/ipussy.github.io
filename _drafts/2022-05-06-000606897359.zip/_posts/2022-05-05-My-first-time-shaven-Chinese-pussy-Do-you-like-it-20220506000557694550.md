---
title:  "My first time shaven Chinese pussy. Do you like it? 💋"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/uxzbegz4oox81.jpg?auto=webp&s=a6fce66c90c4a85bd42d2ae0f7852cb7c5e9ff9d"
thumb: "https://preview.redd.it/uxzbegz4oox81.jpg?width=1080&crop=smart&auto=webp&s=b25000b344f63c2821a3102a75c1d831b927d6b5"
visit: ""
---
My first time shaven Chinese pussy. Do you like it? 💋
