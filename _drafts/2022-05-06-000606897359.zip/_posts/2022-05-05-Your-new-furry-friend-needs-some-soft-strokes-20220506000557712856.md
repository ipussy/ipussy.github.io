---
title:  "Your new furry friend needs some soft strokes 😾"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/d99kadhgznx81.jpg?auto=webp&s=cbfb4421ee8fcd3cf2885d1c6ba6c743ae8d0ebe"
thumb: "https://preview.redd.it/d99kadhgznx81.jpg?width=1080&crop=smart&auto=webp&s=b43985721e4825436fb94987e29d7acb4228fb05"
visit: ""
---
Your new furry friend needs some soft strokes 😾
