---
title:  "Are you sticking your tongue or you dick in first? 💦"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/dw2fj80xbvx81.jpg?auto=webp&s=4c8c3b4319153fbb98f112cb59166971af438c44"
thumb: "https://preview.redd.it/dw2fj80xbvx81.jpg?width=1080&crop=smart&auto=webp&s=232b5ac76d9e42ae2f27cbbb7019285a25bf262d"
visit: ""
---
Are you sticking your tongue or you dick in first? 💦
