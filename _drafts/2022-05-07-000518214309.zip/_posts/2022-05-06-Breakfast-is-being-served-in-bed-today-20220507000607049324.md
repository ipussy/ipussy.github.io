---
title:  "Breakfast is being served in bed today."
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/QraJs6bk86sItJ6pMIbr8SpWJjUFArNvcICoRmy_cGY.jpg?auto=webp&s=fa722b3aacb5969f4548d8e12766ffe9c796ab88"
thumb: "https://external-preview.redd.it/QraJs6bk86sItJ6pMIbr8SpWJjUFArNvcICoRmy_cGY.jpg?width=640&crop=smart&auto=webp&s=16566e45ce5188fe71ee1e1b3e7276f4d0292673"
visit: ""
---
Breakfast is being served in bed today.
