---
title:  "Come split my puffy lips with your tongue?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/v6zT9-x0afvlZb-DRw5epupON9Ym-6dC3RYB0b5Rt6Q.jpg?auto=webp&s=203479622e6d35e598f357be56b321d40a29778d"
thumb: "https://external-preview.redd.it/v6zT9-x0afvlZb-DRw5epupON9Ym-6dC3RYB0b5Rt6Q.jpg?width=1080&crop=smart&auto=webp&s=5167406a96f6460260cd5e0a96f71de9b247c639"
visit: ""
---
Come split my puffy lips with your tongue?
