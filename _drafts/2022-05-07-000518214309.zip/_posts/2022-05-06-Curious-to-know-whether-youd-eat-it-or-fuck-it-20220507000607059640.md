---
title:  "Curious to know whether you’d eat it or fuck it? 👅"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/T5CAV8LNRbqTgI-u1wMJsd4yd0JABf1jNqhmHWB9-OU.jpg?auto=webp&s=afbcb9496a9f426946fb0631243a68bc6971a19a"
thumb: "https://external-preview.redd.it/T5CAV8LNRbqTgI-u1wMJsd4yd0JABf1jNqhmHWB9-OU.jpg?width=320&crop=smart&auto=webp&s=82a6a050b274e424020e1c6724a17a974b7dce2a"
visit: ""
---
Curious to know whether you’d eat it or fuck it? 👅
