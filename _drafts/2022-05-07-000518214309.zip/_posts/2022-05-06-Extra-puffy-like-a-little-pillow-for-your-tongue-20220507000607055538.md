---
title:  "Extra puffy, like a little pillow for your tongue"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/etrtfidveux81.jpg?auto=webp&s=03a9c0abedad15fd23c81f596dd9e88bb5428ba2"
thumb: "https://preview.redd.it/etrtfidveux81.jpg?width=1080&crop=smart&auto=webp&s=ef615cfeb0b4fa1a5e99b45a3c19ade99e3d198f"
visit: ""
---
Extra puffy, like a little pillow for your tongue
