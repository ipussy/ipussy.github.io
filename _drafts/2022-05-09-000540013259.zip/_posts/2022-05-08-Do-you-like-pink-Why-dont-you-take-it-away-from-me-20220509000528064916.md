---
title:  "Do you like pink? Why don't you take it away from me?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/hnasciooq6y81.png?auto=webp&s=abf7feeed2a4712534317a225f5605f1d4c5dcab"
thumb: "https://preview.redd.it/hnasciooq6y81.png?width=1080&crop=smart&auto=webp&s=1bdd96baddeef0900727737adc0965271fdd52fe"
visit: ""
---
Do you like pink? Why don't you take it away from me?
