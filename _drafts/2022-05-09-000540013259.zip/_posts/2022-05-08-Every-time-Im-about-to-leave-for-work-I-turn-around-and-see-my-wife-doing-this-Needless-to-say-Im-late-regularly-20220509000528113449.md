---
title:  "Every time I’m about to leave for work, I turn around and see my wife doing this. Needless to say, I’m late regularly"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/z9m2rp1kb9y81.jpg?auto=webp&s=3dee0b69f623e990ec0a875f9996e09e39b1ed8e"
thumb: "https://preview.redd.it/z9m2rp1kb9y81.jpg?width=1080&crop=smart&auto=webp&s=def2e5afa98eea15da31b147e05e399b2fc319b2"
visit: ""
---
Every time I’m about to leave for work, I turn around and see my wife doing this. Needless to say, I’m late regularly
