---
title:  "It’s good luck if a butterfly lands on you"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/xY-POEyZhP9aEwduEXn0wJOg1z-R_89H0ywA_DXuyGA.jpg?auto=webp&s=eaa6d264cf65b3b777e089079cf248969ec26d98"
thumb: "https://external-preview.redd.it/xY-POEyZhP9aEwduEXn0wJOg1z-R_89H0ywA_DXuyGA.jpg?width=640&crop=smart&auto=webp&s=0969c1b0d016d7874001e10ebf076d8f214838bd"
visit: ""
---
It’s good luck if a butterfly lands on you
