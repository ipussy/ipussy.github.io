---
title:  "What's your favorite Filipino dish?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/ztcakh0bp5y81.gif?format=png8&s=a048f869d195dd2c5ccded63bc53317dcf0664ff"
thumb: "https://preview.redd.it/ztcakh0bp5y81.gif?width=320&crop=smart&format=png8&s=203b61eb9308a3cdab55fb5ec247e4e3ead5d73c"
visit: ""
---
What's your favorite Filipino dish?
