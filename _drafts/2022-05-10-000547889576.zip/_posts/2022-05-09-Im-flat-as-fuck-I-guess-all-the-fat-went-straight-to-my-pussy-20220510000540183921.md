---
title:  "I’m flat as fuck.. I guess all the fat went straight to my pussy! 😅"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/u9kQNegnN34CiqGqJR4IlxTHT3xivuRsP6zJc7FPYgs.jpg?auto=webp&s=f5e04e0b7cbe30b0004f1efd4fdc045a9859cace"
thumb: "https://external-preview.redd.it/u9kQNegnN34CiqGqJR4IlxTHT3xivuRsP6zJc7FPYgs.jpg?width=640&crop=smart&auto=webp&s=ac66c00c6a0da05b74da61e0889d10b881d39118"
visit: ""
---
I’m flat as fuck.. I guess all the fat went straight to my pussy! 😅
