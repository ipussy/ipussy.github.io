---
title:  "It didn't take long for our hands to trade places"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/3n319nhlruy81.jpg?auto=webp&s=b11ce841c6aeaf6dbf6626f02b549b4c167ab762"
thumb: "https://preview.redd.it/3n319nhlruy81.jpg?width=1080&crop=smart&auto=webp&s=854c639c8a9e7925c67345da28c8e02733923c33"
visit: ""
---
It didn't take long for our hands to trade places
