---
title:  "Would this classify as butterfly wings?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/xovi3ofa4vy81.jpg?auto=webp&s=e05ca3de825877f5e37a3bed3b77300db0bb45a7"
thumb: "https://preview.redd.it/xovi3ofa4vy81.jpg?width=1080&crop=smart&auto=webp&s=3455ef57a95decefd08bc93f4f6b5ce47107673d"
visit: ""
---
Would this classify as butterfly wings?
