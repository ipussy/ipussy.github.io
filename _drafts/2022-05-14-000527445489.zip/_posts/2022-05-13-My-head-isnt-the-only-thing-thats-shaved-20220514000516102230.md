---
title:  "My head isn’t the only thing that’s shaved"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/6ht8kc9xn9z81.jpg?auto=webp&s=9ef679d4488785900b000fa66a940426a27eb1d6"
thumb: "https://preview.redd.it/6ht8kc9xn9z81.jpg?width=1080&crop=smart&auto=webp&s=f730e3fe2190cfe5e125fd181299320b4abb4103"
visit: ""
---
My head isn’t the only thing that’s shaved
