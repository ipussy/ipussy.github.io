---
title:  "did you immediately notice the dog in the background?"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/cti3g35yw7z81.jpg?auto=webp&s=421ead4e7e6e90bb97068389261a49c9a5fb6765"
thumb: "https://preview.redd.it/cti3g35yw7z81.jpg?width=1080&crop=smart&auto=webp&s=dee6d1a717624675b2825adb8ccb1e32a01d9eb8"
visit: ""
---
did you immediately notice the dog in the background?
