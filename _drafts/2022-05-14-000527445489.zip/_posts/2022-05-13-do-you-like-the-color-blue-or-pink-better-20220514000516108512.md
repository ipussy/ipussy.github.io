---
title:  "do you like the color blue or pink better?! 😏"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/gzsu5ajsf9z81.jpg?auto=webp&s=271e55d3ef52b02cbf84b9d0f07e86ac545c9959"
thumb: "https://preview.redd.it/gzsu5ajsf9z81.jpg?width=1080&crop=smart&auto=webp&s=9dd72c07bbd40ca327f0aaf3446a02fc0a5e88f0"
visit: ""
---
do you like the color blue or pink better?! 😏
