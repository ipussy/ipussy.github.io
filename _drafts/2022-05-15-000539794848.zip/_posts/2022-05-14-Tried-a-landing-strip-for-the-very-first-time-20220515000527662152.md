---
title:  "Tried a landing strip for the very first time! 😳"
metadate: "hide"
categories: [ Pussy ]
image: "https://preview.redd.it/bgit9kvvsgz81.jpg?auto=webp&s=2a7eef41c44d0d2db7fa7cc1a1aecfdfa452d163"
thumb: "https://preview.redd.it/bgit9kvvsgz81.jpg?width=640&crop=smart&auto=webp&s=0f3aeb95bfb308d4094112ab0197103f57295eac"
visit: ""
---
Tried a landing strip for the very first time! 😳
