---
title:  "My girlfriend freshly shaved after shower"
metadate: "hide"
categories: [ Pussy ]
image: "https://external-preview.redd.it/vu8S9Z3Nqs2zb6BjwB-j1EE60ONykSDNjxbYLzVLSxI.jpg?auto=webp&s=72162ba27e8e95617b7bca2e3f19e5ab33ad0097"
thumb: "https://external-preview.redd.it/vu8S9Z3Nqs2zb6BjwB-j1EE60ONykSDNjxbYLzVLSxI.jpg?width=216&crop=smart&auto=webp&s=59510661f146e07117ee9c9eb4e26b3094204268"
visit: ""
---
My girlfriend freshly shaved after shower
