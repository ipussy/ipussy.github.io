---
title:  "I'd like to sit my strawberry on your face"
metadate: "hide"
categories: [ God Pussy ]
image: "https://external-preview.redd.it/LlZhBqxMl8eJQV78fJ3MqEoLE9FsL9SfqQ2JFy9eu5M.jpg?auto=webp&s=8d0cee0eec7e5745727cce7b2ecd7db74751c846"
thumb: "https://external-preview.redd.it/LlZhBqxMl8eJQV78fJ3MqEoLE9FsL9SfqQ2JFy9eu5M.jpg?width=640&crop=smart&auto=webp&s=c4ad8aff84ca67bf0627145d005326586af942e7"
visit: ""
---
I'd like to sit my strawberry on your face
