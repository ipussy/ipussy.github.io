---
title:  "Waiting in the drive thru Starbucks"
metadate: "hide"
categories: [ God Pussy ]
image: "https://preview.redd.it/mvdofzz7ouz81.jpg?auto=webp&s=cebac7eec289449f38cf413595a7bdca0963866e"
thumb: "https://preview.redd.it/mvdofzz7ouz81.jpg?width=1080&crop=smart&auto=webp&s=dbac0c2a4cbb54724f4e82d935196c4c9340fe4c"
visit: ""
---
Waiting in the drive thru Starbucks
